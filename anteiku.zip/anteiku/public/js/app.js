document.addEventListener('DOMContentLoaded', () => {
  // Sidebar responsif
  const sb = document.getElementById('sidebar');
  document.getElementById('sidebarToggle')?.addEventListener('click', e => { e.stopPropagation(); sb.classList.toggle('show'); });
  document.addEventListener('click', e => {
    if (sb && sb.classList.contains('show') && !sb.contains(e.target)) sb.classList.remove('show');
  });

  // Konfirmasi sebelum hapus / aksi penting
  document.querySelectorAll('form[data-confirm]').forEach(f =>
    f.addEventListener('submit', e => { if (!confirm(f.dataset.confirm)) e.preventDefault(); }));

  // Preview gambar upload
  document.querySelectorAll('input[type=file][data-preview]').forEach(inp =>
    inp.addEventListener('change', () => {
      const img = document.querySelector(inp.dataset.preview);
      if (img && inp.files[0]) { img.src = URL.createObjectURL(inp.files[0]); img.classList.remove('d-none'); }
    }));

  // Filter bar: kirim otomatis saat dropdown berubah
  document.querySelectorAll('form.auto-submit select').forEach(s => s.addEventListener('change', () => s.form.submit()));
});
