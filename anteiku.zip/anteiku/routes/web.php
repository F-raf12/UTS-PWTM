<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\SaleController;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;

/*Publik (hanya untuk tamu / belum login) */
Route::redirect('/', '/dashboard');

Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [AuthController::class, 'login'])->middleware('throttle:10,1');
});

/* Terproteksi: wajib login & akun aktif */
Route::middleware(['auth', 'active'])->group(function () {
    Route::post('/logout', [AuthController::class, 'logout'])->name('logout');
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

    /*  Admin & Kasir  */
    Route::get('/produk', [ProductController::class, 'index'])->name('products.index');   // kasir: hanya lihat

    Route::get('/pelanggan', [CustomerController::class, 'index'])->name('customers.index');
    Route::get('/pelanggan/tambah', [CustomerController::class, 'create'])->name('customers.create');
    Route::post('/pelanggan', [CustomerController::class, 'store'])->name('customers.store');
    Route::get('/pelanggan/{customer}/ubah', [CustomerController::class, 'edit'])->name('customers.edit');
    Route::put('/pelanggan/{customer}', [CustomerController::class, 'update'])->name('customers.update');

    Route::get('/transaksi/baru', [SaleController::class, 'create'])->name('sales.create');
    Route::post('/transaksi', [SaleController::class, 'store'])->name('sales.store');
    Route::get('/transaksi', [SaleController::class, 'index'])->name('sales.index');
    Route::get('/transaksi/{sale}', [SaleController::class, 'show'])->name('sales.show');

    /* Khusus Admin */
    Route::middleware('role:admin')->group(function () {
        Route::delete('/pelanggan/{customer}', [CustomerController::class, 'destroy'])->name('customers.destroy');

        Route::get('/produk/tambah', [ProductController::class, 'create'])->name('products.create');
        Route::post('/produk', [ProductController::class, 'store'])->name('products.store');
        Route::get('/produk/{product}/ubah', [ProductController::class, 'edit'])->name('products.edit');
        Route::put('/produk/{product}', [ProductController::class, 'update'])->name('products.update');
        Route::delete('/produk/{product}', [ProductController::class, 'destroy'])->name('products.destroy');

        Route::resource('kategori', CategoryController::class)
            ->parameters(['kategori' => 'category'])->except('show')->names('categories');

        Route::post('/transaksi/{sale}/batal', [SaleController::class, 'cancel'])->name('sales.cancel');

        Route::get('/laporan', [ReportController::class, 'index'])->name('reports.index');
        Route::get('/laporan/pdf', [ReportController::class, 'pdf'])->name('reports.pdf');

        Route::resource('pengguna', UserController::class)
            ->parameters(['pengguna' => 'user'])->except('show')->names('users');
    });
});
