<?php

use App\Http\Middleware\CheckRole;
use App\Http\Middleware\EnsureUserActive;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware): void {
        $middleware->alias([
            'role'   => CheckRole::class,
            'active' => EnsureUserActive::class,
        ]);
        // Pengguna yang belum login diarahkan ke halaman login
        $middleware->redirectGuestsTo(fn () => route('login'));
        // Pengguna yang sudah login tidak boleh membuka halaman login lagi
        $middleware->redirectUsersTo(fn () => route('dashboard'));
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        //
    })->create();
