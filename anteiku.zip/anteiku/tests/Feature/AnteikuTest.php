<?php

namespace Tests\Feature;

use App\Models\Category;
use App\Models\Customer;
use App\Models\Product;
use App\Models\Sale;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class AnteikuTest extends TestCase
{
    use RefreshDatabase;

    private function admin(): User { return User::factory()->create(['role' => 'admin']); }
    private function kasir(): User { return User::factory()->create(['role' => 'kasir']); }
    private function product(int $stock = 10, int $price = 20000): Product
    {
        $cat = Category::firstOrCreate(['name' => 'Coffee']);
        return Product::create(['category_id' => $cat->id, 'name' => 'Latte ' . uniqid(), 'price' => $price, 'stock' => $stock, 'is_active' => true]);
    }

    public function test_guest_is_redirected_to_login(): void
    {
        foreach (['/dashboard', '/produk', '/pelanggan', '/transaksi', '/transaksi/baru', '/laporan', '/pengguna', '/kategori'] as $url) {
            $this->get($url)->assertRedirect('/login');
        }
    }

    public function test_login_and_logout(): void
    {
        $u = User::factory()->create(['email' => 'a@b.test', 'password' => 'secret123']);
        $this->post('/login', ['email' => 'a@b.test', 'password' => 'salah'])->assertSessionHasErrors('email');
        $this->post('/login', ['email' => 'a@b.test', 'password' => 'secret123'])->assertRedirect('/dashboard');
        $this->assertAuthenticatedAs($u);
        $this->post('/logout')->assertRedirect('/login');
        $this->assertGuest();
    }

    public function test_inactive_user_cannot_login(): void
    {
        User::factory()->create(['email' => 'x@b.test', 'password' => 'secret123', 'is_active' => false]);
        $this->post('/login', ['email' => 'x@b.test', 'password' => 'secret123'])->assertSessionHasErrors('email');
        $this->assertGuest();
    }

    public function test_kasir_is_blocked_from_admin_pages(): void
    {
        $k = $this->kasir();
        foreach (['/kategori', '/laporan', '/pengguna', '/produk/tambah', '/pengguna/create'] as $url) {
            $this->actingAs($k)->get($url)->assertForbidden();
        }
        $this->actingAs($k)->post('/produk', [])->assertForbidden();
        $c = Customer::create(['name' => 'Z']);
        $this->actingAs($k)->delete("/pelanggan/{$c->id}")->assertForbidden();
        foreach (['/dashboard', '/produk', '/pelanggan', '/transaksi', '/transaksi/baru'] as $url) {
            $this->actingAs($k)->get($url)->assertOk();
        }
    }

    public function test_admin_can_open_all_pages(): void
    {
        $a = $this->admin();
        foreach (['/dashboard', '/kategori', '/kategori/create', '/produk', '/produk/tambah', '/pelanggan', '/pelanggan/tambah',
                  '/transaksi', '/transaksi/baru', '/laporan', '/pengguna', '/pengguna/create'] as $url) {
            $this->actingAs($a)->get($url)->assertOk();
        }
    }

    public function test_category_crud_validation_and_restrict(): void
    {
        $a = $this->admin();
        $this->actingAs($a)->post('/kategori', ['name' => ''])->assertSessionHasErrors('name');
        $this->actingAs($a)->post('/kategori', ['name' => 'Dessert'])->assertRedirect('/kategori');
        $cat = Category::where('name', 'Dessert')->first();
        $this->actingAs($a)->post('/kategori', ['name' => 'Dessert'])->assertSessionHasErrors('name');
        $this->actingAs($a)->put("/kategori/{$cat->id}", ['name' => 'Dessert 2'])->assertRedirect('/kategori');
        $this->assertDatabaseHas('categories', ['name' => 'Dessert 2']);

        $p = $this->product();
        $this->actingAs($a)->delete("/kategori/{$p->category_id}")->assertSessionHas('error');
        $this->actingAs($a)->delete("/kategori/{$cat->id}");
        $this->assertDatabaseMissing('categories', ['id' => $cat->id]);
    }

    public function test_product_crud_with_image(): void
    {
        \Storage::fake('public');
        $a = $this->admin();
        $cat = Category::create(['name' => 'Coffee']);
        $this->actingAs($a)->post('/produk', ['name' => 'X', 'category_id' => $cat->id, 'price' => -5, 'stock' => 1])->assertSessionHasErrors('price');
        $this->actingAs($a)->post('/produk', [
            'name' => 'Mocha', 'category_id' => $cat->id, 'price' => 25000, 'stock' => 5, 'is_active' => 1,
            'image' => \Illuminate\Http\UploadedFile::fake()->image('m.jpg'),
        ])->assertRedirect('/produk');
        $p = Product::where('name', 'Mocha')->first();
        \Storage::disk('public')->assertExists($p->image);
        $this->actingAs($a)->put("/produk/{$p->id}", ['name' => 'Mocha B', 'category_id' => $cat->id, 'price' => 26000, 'stock' => 7])->assertRedirect('/produk');
        $this->assertDatabaseHas('products', ['name' => 'Mocha B', 'price' => 26000, 'is_active' => false]);
        $this->actingAs($a)->delete("/produk/{$p->id}");
        $this->assertDatabaseMissing('products', ['id' => $p->id]);
    }

    public function test_list_search_filter_sort_paginate(): void
    {
        $a = $this->admin();
        $cat = Category::create(['name' => 'Coffee']);
        foreach (range(1, 15) as $i) {
            Product::create(['category_id' => $cat->id, 'name' => "Produk $i", 'price' => $i * 1000, 'stock' => $i]);
        }
        $r = $this->actingAs($a)->get('/produk')->assertOk();
        $this->assertCount(10, $r->viewData('products'));
        $this->assertSame(15, $r->viewData('products')->total());
        $this->actingAs($a)->get('/produk?page=2')->assertOk();
        $r = $this->actingAs($a)->get('/produk?q=Produk 15')->assertOk();
        $this->assertSame(1, $r->viewData('products')->total());
        $r = $this->actingAs($a)->get('/produk?sort=price&dir=desc');
        $this->assertSame('Produk 15', $r->viewData('products')->first()->name);
        $r = $this->actingAs($a)->get('/produk?stock=low');
        $this->assertSame(10, $r->viewData('products')->total());
        // kolom sorting sembarang tidak boleh error / injeksi
        $this->actingAs($a)->get('/produk?sort=password;drop&dir=zzz')->assertOk();
    }

    public function test_customer_crud(): void
    {
        $k = $this->kasir();
        $this->actingAs($k)->post('/pelanggan', ['name' => 'Budi', 'phone' => 'abc'])->assertSessionHasErrors('phone');
        $this->actingAs($k)->post('/pelanggan', ['name' => 'Budi', 'phone' => '0812-3456-789'])->assertRedirect('/pelanggan');
        $c = Customer::first();
        $this->actingAs($k)->put("/pelanggan/{$c->id}", ['name' => 'Budi S'])->assertRedirect('/pelanggan');
        $this->actingAs($this->admin())->delete("/pelanggan/{$c->id}");
        $this->assertDatabaseCount('customers', 0);
    }

    public function test_sale_calculates_totals_and_reduces_stock(): void
    {
        $k = $this->kasir();
        $p1 = $this->product(10, 20000);
        $p2 = $this->product(5, 15000);
        $c = Customer::create(['name' => 'Ani']);

        $this->actingAs($k)->post('/transaksi', [
            'items' => [['product_id' => $p1->id, 'qty' => 2], ['product_id' => $p2->id, 'qty' => 1]],
            'customer_id' => $c->id, 'payment_method' => 'tunai', 'paid' => 100000,
        ])->assertRedirect();

        $sale = Sale::first();
        $this->assertSame(55000, $sale->total);
        $this->assertSame(45000, $sale->change_amount);
        $this->assertSame($k->id, $sale->user_id);
        $this->assertCount(2, $sale->details);
        $this->assertSame(40000, $sale->details->firstWhere('product_id', $p1->id)->subtotal);
        $this->assertSame(8, $p1->fresh()->stock);
        $this->assertSame(4, $p2->fresh()->stock);
        $this->actingAs($k)->get("/transaksi/{$sale->id}")->assertOk()->assertSee($sale->invoice_no);
    }

    public function test_sale_validation_rules(): void
    {
        $k = $this->kasir();
        $p = $this->product(3, 10000);
        $this->actingAs($k)->post('/transaksi', ['items' => [], 'payment_method' => 'tunai'])->assertSessionHasErrors('items');
        $this->actingAs($k)->post('/transaksi', ['items' => [['product_id' => $p->id, 'qty' => 5]], 'payment_method' => 'tunai', 'paid' => 999999])->assertSessionHasErrors('items');
        $this->actingAs($k)->post('/transaksi', ['items' => [['product_id' => $p->id, 'qty' => 2]], 'payment_method' => 'tunai', 'paid' => 5000])->assertSessionHasErrors('paid');
        $this->assertDatabaseCount('sales', 0);
        $this->assertSame(3, $p->fresh()->stock); // rollback, stok tidak berubah
        // non-tunai: paid otomatis = total
        $this->actingAs($k)->post('/transaksi', ['items' => [['product_id' => $p->id, 'qty' => 1]], 'payment_method' => 'qris'])->assertRedirect();
        $this->assertSame(10000, Sale::first()->paid);
    }

    public function test_kasir_only_sees_own_sales_and_admin_can_cancel(): void
    {
        $k1 = $this->kasir(); $k2 = $this->kasir(); $a = $this->admin();
        $p = $this->product(10, 10000);
        $mk = fn ($u) => $this->actingAs($u)->post('/transaksi', ['items' => [['product_id' => $p->id, 'qty' => 1]], 'payment_method' => 'qris']);
        $mk($k1); $mk($k2);
        $s1 = Sale::where('user_id', $k1->id)->first();
        $s2 = Sale::where('user_id', $k2->id)->first();

        $r = $this->actingAs($k1)->get('/transaksi');
        $this->assertSame(1, $r->viewData('sales')->total());
        $this->actingAs($k1)->get("/transaksi/{$s2->id}")->assertForbidden();
        $this->actingAs($a)->get('/transaksi')->assertOk();
        $this->assertSame(2, $this->actingAs($a)->get('/transaksi')->viewData('sales')->total());

        $this->actingAs($k1)->post("/transaksi/{$s1->id}/batal")->assertForbidden();
        $this->actingAs($a)->post("/transaksi/{$s1->id}/batal")->assertSessionHas('status');
        $this->assertSame('cancelled', $s1->fresh()->status);
        $this->assertSame(9, $p->fresh()->stock); // 10 - 2 + 1
    }

    public function test_report_date_range_and_pdf(): void
    {
        $a = $this->admin();
        $p = $this->product(50, 10000);
        $mk = fn ($date) => Sale::create(['invoice_no' => 'T' . uniqid(), 'user_id' => $a->id, 'sold_at' => $date, 'total' => 10000, 'paid' => 10000, 'payment_method' => 'tunai', 'status' => 'completed']);
        $mk('2026-01-10 10:00'); $mk('2026-01-20 10:00'); $mk('2026-02-05 10:00');

        $r = $this->actingAs($a)->get('/laporan?from=2026-01-01&to=2026-01-31')->assertOk();
        $this->assertSame(2, $r->viewData('summary')['count']);
        $this->assertSame(20000, $r->viewData('summary')['revenue']);
        $this->actingAs($a)->get('/laporan?from=2026-02-01&to=2026-01-01')->assertSessionHasErrors('to');
        $this->actingAs($a)->get('/laporan/pdf?from=2026-01-01&to=2026-01-31')->assertOk()->assertHeader('content-type', 'application/pdf');
    }

    public function test_user_management_rules(): void
    {
        $a = $this->admin();
        $this->actingAs($a)->post('/pengguna', ['name' => 'K', 'email' => 'k@x.test', 'role' => 'boss', 'password' => '12345678', 'password_confirmation' => '12345678'])->assertSessionHasErrors('role');
        $this->actingAs($a)->post('/pengguna', ['name' => 'K', 'email' => 'k@x.test', 'role' => 'kasir', 'password' => '123', 'password_confirmation' => '123'])->assertSessionHasErrors('password');
        $this->actingAs($a)->post('/pengguna', ['name' => 'K', 'email' => 'k@x.test', 'role' => 'kasir', 'password' => '12345678', 'password_confirmation' => '12345678', 'is_active' => 1])->assertRedirect('/pengguna');
        $this->assertTrue(User::where('email', 'k@x.test')->first()->isKasir());
        // tidak bisa hapus / turunkan diri sendiri
        $this->actingAs($a)->delete("/pengguna/{$a->id}")->assertSessionHas('error');
        $this->actingAs($a)->put("/pengguna/{$a->id}", ['name' => 'A', 'email' => $a->email, 'role' => 'kasir', 'is_active' => 1])->assertSessionHas('error');
        // user nonaktif langsung ditendang
        $k = User::where('email', 'k@x.test')->first();
        $k->update(['is_active' => false]);
        $this->actingAs($k)->get('/dashboard')->assertRedirect('/login');
    }
}
