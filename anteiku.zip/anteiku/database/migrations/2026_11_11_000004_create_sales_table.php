<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('sales', function (Blueprint $table) {
            $table->id();
            $table->string('invoice_no', 30)->unique();
            $table->foreignId('user_id')->constrained('users')->restrictOnDelete();      // kasir yang melayani
            $table->foreignId('customer_id')->nullable()->constrained('customers')->nullOnDelete(); // null = pelanggan umum
            $table->dateTime('sold_at')->index();
            $table->unsignedInteger('total');
            $table->unsignedInteger('paid');
            $table->unsignedInteger('change_amount')->default(0);
            $table->string('payment_method', 20)->default('tunai'); // tunai | qris | debit
            $table->string('status', 20)->default('completed')->index(); // completed | cancelled
            $table->string('notes')->nullable();
            $table->timestamps();
        });

        Schema::create('sale_details', function (Blueprint $table) {
            $table->id();
            $table->foreignId('sale_id')->constrained('sales')->cascadeOnDelete();
            $table->foreignId('product_id')->constrained('products')->restrictOnDelete();
            $table->string('product_name', 120);   // snapshot nama saat transaksi
            $table->unsignedInteger('price');      // snapshot harga saat transaksi
            $table->unsignedInteger('qty');
            $table->unsignedInteger('subtotal');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('sale_details');
        Schema::dropIfExists('sales');
    }
};
