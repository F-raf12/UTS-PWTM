<?php

namespace Database\Seeders;

use App\Models\Category;
use App\Models\Customer;
use App\Models\Product;
use App\Models\Sale;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        /* ---- Users: 1 Admin + 2 Kasir (password: password) ---- */
        $admin = User::updateOrCreate(['email' => 'admin@anteiku.test'], [
            'name' => 'Admin Anteiku', 'password' => 'password', 'role' => User::ROLE_ADMIN, 'is_active' => true,
        ]);
        $kasir1 = User::updateOrCreate(['email' => 'kasir@anteiku.test'], [
            'name' => 'Kasir Touka', 'password' => 'password', 'role' => User::ROLE_KASIR, 'is_active' => true,
        ]);
        $kasir2 = User::updateOrCreate(['email' => 'kasir2@anteiku.test'], [
            'name' => 'Kasir Hinami', 'password' => 'password', 'role' => User::ROLE_KASIR, 'is_active' => true,
        ]);

        /* ---- Categories ---- */
        $cats = [];
        foreach ([
            'Coffee'     => 'Kopi espresso dan seduh manual',
            'Non-Coffee' => 'Minuman tanpa kopi: teh, cokelat, matcha',
            'Dessert'    => 'Kue manis dan hidangan penutup',
            'Pastry'     => 'Roti dan pastry yang dipanggang setiap hari',
        ] as $name => $desc) {
            $cats[$name] = Category::firstOrCreate(['name' => $name], ['description' => $desc]);
        }

        /* ---- Products ---- */
        $products = [
            ['Coffee', 'Espresso', 18000, 'Single shot espresso pekat'],
            ['Coffee', 'Americano', 22000, 'Espresso dengan air panas'],
            ['Coffee', 'Cafe Latte', 28000, 'Espresso dan susu steamed'],
            ['Coffee', 'Cappuccino', 28000, 'Espresso, susu, dan foam tebal'],
            ['Coffee', 'Caramel Macchiato', 32000, 'Latte dengan saus karamel'],
            ['Coffee', 'Iced Coffee Aren', 26000, 'Kopi susu gula aren dingin'],
            ['Non-Coffee', 'Matcha Latte', 30000, 'Matcha Jepang dengan susu'],
            ['Non-Coffee', 'Chocolate', 27000, 'Cokelat premium hangat/dingin'],
            ['Non-Coffee', 'Lemon Tea', 20000, 'Teh dengan perasan lemon segar'],
            ['Dessert', 'Tiramisu', 35000, 'Tiramisu klasik dengan bubuk kakao'],
            ['Dessert', 'Cheesecake', 38000, 'New York cheesecake'],
            ['Dessert', 'Brownies', 24000, 'Brownies cokelat lembut'],
            ['Dessert', 'Affogato', 32000, 'Es krim vanila dengan espresso'],
            ['Pastry', 'Croissant', 25000, 'Croissant butter renyah'],
            ['Pastry', 'Pain au Chocolat', 28000, 'Pastry isi cokelat'],
            ['Pastry', 'Cinnamon Roll', 26000, 'Roti kayu manis dengan glaze'],
        ];
        $stocks = [];
        foreach ($products as [$cat, $name, $price, $desc]) {
            $stocks[$name] = Product::updateOrCreate(['name' => $name], [
                'category_id' => $cats[$cat]->id, 'price' => $price, 'stock' => 200, 'description' => $desc, 'is_active' => true,
            ]);
        }

        /* ---- Customers ---- */
        foreach ([
            ['Ayato Kirishima', '081234567801', 'ayato@example.com', 'Jl. Melati No. 12, Jakarta'],
            ['Kaneki Ken', '081234567802', 'kaneki@example.com', 'Jl. Kenanga No. 3, Bandung'],
            ['Rize Kamishiro', '081234567803', null, 'Jl. Anggrek No. 8, Jakarta'],
            ['Hide Nagachika', '081234567804', 'hide@example.com', 'Jl. Dahlia No. 21, Depok'],
            ['Yoshimura', '081234567805', null, 'Jl. Mawar No. 5, Bogor'],
            ['Tsukiyama Shu', '081234567806', 'shu@example.com', 'Jl. Cempaka No. 17, Jakarta'],
            ['Nishiki Nishio', '081234567807', null, 'Jl. Flamboyan No. 9, Tangerang'],
            ['Kimi Nishino', '081234567808', 'kimi@example.com', 'Jl. Teratai No. 30, Bekasi'],
        ] as [$name, $phone, $email, $address]) {
            Customer::firstOrCreate(['name' => $name], compact('phone', 'email', 'address'));
        }

        /* ---- Contoh transaksi 30 hari terakhir (hanya jika belum ada) ---- */
        if (Sale::count() === 0) {
            $this->seedSales([$admin, $kasir1, $kasir2]);
        }
    }

    private function seedSales(array $cashiers): void
    {
        mt_srand(2026); // hasil seeder konsisten
        $products = Product::all();
        $customerIds = Customer::pluck('id')->all();
        $methods = ['tunai', 'tunai', 'qris', 'debit'];
        $counter = [];

        DB::transaction(function () use ($products, $customerIds, $cashiers, $methods, &$counter) {
            for ($day = 29; $day >= 0; $day--) {
                $date = now()->subDays($day);
                $n = mt_rand(2, 6);
                for ($i = 0; $i < $n; $i++) {
                    $soldAt = $date->copy()->setTime(mt_rand(8, 21), mt_rand(0, 59));
                    $picked = $products->random(mt_rand(1, 3));
                    $lines = [];
                    $total = 0;
                    foreach ($picked as $p) {
                        $qty = mt_rand(1, 3);
                        $lines[] = ['product_id' => $p->id, 'product_name' => $p->name, 'price' => $p->price, 'qty' => $qty, 'subtotal' => $p->price * $qty];
                        $total += $p->price * $qty;
                        $p->stock -= $qty;
                    }
                    $method = $methods[array_rand($methods)];
                    $paid = $method === 'tunai' ? (int) (ceil($total / 10000) * 10000) : $total;
                    $key = $soldAt->format('Ymd');
                    $counter[$key] = ($counter[$key] ?? 0) + 1;

                    $sale = Sale::create([
                        'invoice_no' => 'ANT-' . $key . '-' . str_pad((string) $counter[$key], 4, '0', STR_PAD_LEFT),
                        'user_id' => $cashiers[array_rand($cashiers)]->id,
                        'customer_id' => mt_rand(0, 2) ? $customerIds[array_rand($customerIds)] : null,
                        'sold_at' => $soldAt, 'total' => $total, 'paid' => $paid,
                        'change_amount' => $paid - $total, 'payment_method' => $method, 'status' => Sale::COMPLETED,
                        'created_at' => $soldAt, 'updated_at' => $soldAt,
                    ]);
                    $sale->details()->createMany($lines);
                }
            }
            foreach ($products as $p) {
                $p->save();
            }
            // Beberapa produk sengaja dibuat stok menipis agar peringatan stok terlihat
            Product::where('name', 'Cheesecake')->update(['stock' => 6]);
            Product::where('name', 'Affogato')->update(['stock' => 3]);
            Product::where('name', 'Pain au Chocolat')->update(['stock' => 0]);
        });
    }
}
