<?php

namespace App\Providers;

use Carbon\Carbon;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\Blade;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        //
    }

    public function boot(): void
    {
        Carbon::setLocale('id');
        Paginator::useBootstrapFive();

        // @rp($angka) -> Rp 1.250.000
        Blade::directive('rp', fn ($e) => "<?php echo 'Rp ' . number_format((int) ($e), 0, ',', '.'); ?>");
    }
}
