<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use App\Models\Product;
use App\Models\Sale;
use App\Models\SaleDetail;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index(Request $request)
    {
        $user = $request->user();
        $sales = fn () => Sale::completed()->visibleTo($user);

        $totalSales = (int) $sales()->sum('total');
        $todaySales = (int) $sales()->whereDate('sold_at', today())->sum('total');
        $monthSales = (int) $sales()->whereBetween('sold_at', [now()->startOfMonth(), now()->endOfMonth()])->sum('total');

        // Penjualan 7 hari terakhir (hari tanpa transaksi tetap tampil = 0)
        $start = today()->subDays(6);
        $byDay = $sales()->where('sold_at', '>=', $start)
            ->get(['sold_at', 'total'])->groupBy(fn ($s) => $s->sold_at->toDateString())
            ->map(fn ($g) => $g->sum('total'));
        $chart = collect(range(0, 6))->map(function ($i) use ($start, $byDay) {
            $d = $start->copy()->addDays($i);

            return ['label' => $d->translatedFormat('D'), 'date' => $d->translatedFormat('d M'), 'total' => (int) ($byDay[$d->toDateString()] ?? 0)];
        });

        $bestSellers = SaleDetail::selectRaw('product_id, product_name, SUM(qty) as qty, SUM(subtotal) as revenue')
            ->whereHas('sale', fn ($q) => $q->completed()->visibleTo($user))
            ->groupBy('product_id', 'product_name')->orderByDesc('qty')->limit(5)->get();

        return view('dashboard.index', [
            'totalSales'   => $totalSales,
            'todaySales'   => $todaySales,
            'monthSales'   => $monthSales,
            'saleCount'    => $sales()->count(),
            'todayCount'   => $sales()->whereDate('sold_at', today())->count(),
            'productCount' => Product::count(),
            'customerCount'=> Customer::count(),
            'chart'        => $chart,
            'chartMax'     => max(1, $chart->max('total')),
            'bestSellers'  => $bestSellers,
            'lowStock'     => Product::where('stock', '<=', Product::LOW_STOCK)->where('is_active', true)->orderBy('stock')->limit(5)->get(),
            'recent'       => Sale::with('customer', 'user')->visibleTo($user)->latest('sold_at')->limit(6)->get(),
        ]);
    }
}
