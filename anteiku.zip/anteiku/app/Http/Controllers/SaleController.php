<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Customer;
use App\Models\Product;
use App\Models\Sale;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;

class SaleController extends Controller
{
    /** Riwayat transaksi: Admin melihat semua, Kasir hanya miliknya. */
    public function index(Request $request)
    {
        $request->validate([
            'from' => ['nullable', 'date'],
            'to'   => ['nullable', 'date', 'after_or_equal:from'],
        ]);
        [$sort, $dir] = $this->sorting($request, ['invoice_no', 'sold_at', 'total'], 'sold_at', 'desc');

        $sales = Sale::with(['customer', 'user'])->withSum('details as items_count', 'qty')
            ->visibleTo($request->user())
            ->when($request->q, fn ($q, $s) => $q->where(fn ($w) => $w
                ->where('invoice_no', 'like', "%$s%")
                ->orWhereHas('customer', fn ($c) => $c->where('name', 'like', "%$s%"))))
            ->when($request->status, fn ($q, $s) => $q->where('status', $s))
            ->when($request->payment, fn ($q, $m) => $q->where('payment_method', $m))
            ->when($request->from, fn ($q, $d) => $q->whereDate('sold_at', '>=', $d))
            ->when($request->to, fn ($q, $d) => $q->whereDate('sold_at', '<=', $d))
            ->when($request->user()->isAdmin() && $request->cashier, fn ($q) => $q->where('user_id', $request->cashier))
            ->orderBy($sort, $dir)
            ->paginate(10)->withQueryString();

        return view('sales.index', [
            'sales'    => $sales,
            'cashiers' => $request->user()->isAdmin() ? User::orderBy('name')->get() : collect(),
            'sort' => $sort, 'dir' => $dir,
        ]);
    }

    /** Halaman kasir (point of sale). */
    public function create()
    {
        return view('sales.create', [
            'products'   => Product::with('category')->where('is_active', true)->orderBy('name')->get(),
            'categories' => Category::orderBy('name')->get(),
            'customers'  => Customer::orderBy('name')->get(),
        ]);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'items'              => ['required', 'array', 'min:1'],
            'items.*.product_id' => ['required', 'integer', 'distinct', 'exists:products,id'],
            'items.*.qty'        => ['required', 'integer', 'min:1', 'max:999'],
            'customer_id'        => ['nullable', 'exists:customers,id'],
            'payment_method'     => ['required', Rule::in(array_keys(Sale::METHODS))],
            'paid'               => ['nullable', 'integer', 'min:0'],
            'notes'              => ['nullable', 'string', 'max:255'],
        ], [
            'items.required' => 'Keranjang masih kosong. Pilih minimal satu produk.',
            'items.min'      => 'Keranjang masih kosong. Pilih minimal satu produk.',
        ]);

        $sale = DB::transaction(function () use ($data, $request) {
            // Kunci baris produk agar stok aman dari transaksi bersamaan
            $products = Product::whereIn('id', collect($data['items'])->pluck('product_id'))
                ->lockForUpdate()->get()->keyBy('id');

            $lines = [];
            $total = 0;
            foreach ($data['items'] as $i => $item) {
                $product = $products[$item['product_id']];
                $qty = (int) $item['qty'];

                if (! $product->is_active) {
                    throw ValidationException::withMessages(['items' => "Produk {$product->name} tidak aktif."]);
                }
                if ($qty > $product->stock) {
                    throw ValidationException::withMessages(['items' => "Stok {$product->name} tidak cukup (tersisa {$product->stock})."]);
                }

                // Harga selalu diambil dari database, bukan dari input browser
                $subtotal = $product->price * $qty;
                $total += $subtotal;
                $lines[] = [
                    'product_id' => $product->id, 'product_name' => $product->name,
                    'price' => $product->price, 'qty' => $qty, 'subtotal' => $subtotal,
                ];
                $product->decrement('stock', $qty);
            }

            $paid = $data['payment_method'] === 'tunai' ? (int) ($data['paid'] ?? 0) : $total;
            if ($paid < $total) {
                throw ValidationException::withMessages(['paid' => 'Jumlah bayar kurang dari total belanja.']);
            }

            $sale = Sale::create([
                'invoice_no'     => Sale::generateInvoiceNo(),
                'user_id'        => $request->user()->id,
                'customer_id'    => $data['customer_id'] ?? null,
                'sold_at'        => now(),
                'total'          => $total,
                'paid'           => $paid,
                'change_amount'  => $paid - $total,
                'payment_method' => $data['payment_method'],
                'status'         => Sale::COMPLETED,
                'notes'          => $data['notes'] ?? null,
            ]);
            $sale->details()->createMany($lines);

            return $sale;
        });

        return redirect()->route('sales.show', $sale)->with('status', 'Transaksi ' . $sale->invoice_no . ' berhasil disimpan.');
    }

    public function show(Request $request, Sale $sale)
    {
        abort_unless($request->user()->isAdmin() || $sale->user_id === $request->user()->id, 403, 'Anda hanya dapat melihat transaksi milik Anda.');

        $sale->load(['details', 'customer', 'user']);

        return view('sales.show', compact('sale'));
    }

    /** Pembatalan transaksi (Admin): stok dikembalikan dan transaksi tidak dihitung di laporan. */
    public function cancel(Sale $sale)
    {
        if ($sale->status === Sale::CANCELLED) {
            return back()->with('error', 'Transaksi sudah dibatalkan.');
        }

        DB::transaction(function () use ($sale) {
            foreach ($sale->details as $d) {
                Product::whereKey($d->product_id)->increment('stock', $d->qty);
            }
            $sale->update(['status' => Sale::CANCELLED]);
        });

        return back()->with('status', 'Transaksi dibatalkan dan stok dikembalikan.');
    }
}
