<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use Illuminate\Http\Request;

class CustomerController extends Controller
{
    public function index(Request $request)
    {
        [$sort, $dir] = $this->sorting($request, ['name', 'phone', 'sales_count', 'created_at'], 'name');

        $customers = Customer::withCount('sales')
            ->when($request->q, fn ($q, $s) => $q->where(fn ($w) => $w
                ->where('name', 'like', "%$s%")->orWhere('phone', 'like', "%$s%")->orWhere('email', 'like', "%$s%")))
            ->when($request->filter === 'buyer', fn ($q) => $q->has('sales'))
            ->when($request->filter === 'new', fn ($q) => $q->doesntHave('sales'))
            ->orderBy($sort, $dir)
            ->paginate(10)->withQueryString();

        return view('customers.index', compact('customers', 'sort', 'dir'));
    }

    public function create()
    {
        return view('customers.form', ['customer' => new Customer()]);
    }

    public function store(Request $request)
    {
        Customer::create($this->validated($request));

        return redirect()->route('customers.index')->with('status', 'Pelanggan berhasil ditambahkan.');
    }

    public function edit(Customer $customer)
    {
        return view('customers.form', compact('customer'));
    }

    public function update(Request $request, Customer $customer)
    {
        $customer->update($this->validated($request));

        return redirect()->route('customers.index')->with('status', 'Data pelanggan berhasil diperbarui.');
    }

    public function destroy(Customer $customer)
    {
        $customer->delete(); // transaksi lama tetap tersimpan (customer_id -> null)

        return back()->with('status', 'Pelanggan berhasil dihapus.');
    }

    private function validated(Request $request): array
    {
        return $request->validate([
            'name'    => ['required', 'string', 'max:100'],
            'phone'   => ['nullable', 'regex:/^[0-9+\-\s]{6,20}$/'],
            'email'   => ['nullable', 'email', 'max:255'],
            'address' => ['nullable', 'string', 'max:255'],
        ]);
    }
}
