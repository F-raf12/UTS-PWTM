<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

abstract class Controller
{
    /**
     * Ambil kolom & arah sorting dari query string dengan daftar putih kolom,
     * agar aman dari input sembarang. Mengembalikan [kolom, arah].
     */
    protected function sorting(Request $request, array $allowed, string $default, string $defaultDir = 'asc'): array
    {
        $sort = in_array($request->query('sort'), $allowed, true) ? $request->query('sort') : $default;
        $dir  = in_array($request->query('dir'), ['asc', 'desc'], true) ? $request->query('dir') : $defaultDir;

        return [$sort, $dir];
    }
}
