<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class UserController extends Controller
{
    public function index(Request $request)
    {
        [$sort, $dir] = $this->sorting($request, ['name', 'email', 'role', 'created_at'], 'name');

        $users = User::withCount('sales')
            ->when($request->q, fn ($q, $s) => $q->where(fn ($w) => $w->where('name', 'like', "%$s%")->orWhere('email', 'like', "%$s%")))
            ->when($request->role, fn ($q, $r) => $q->where('role', $r))
            ->when($request->status === 'active', fn ($q) => $q->where('is_active', true))
            ->when($request->status === 'inactive', fn ($q) => $q->where('is_active', false))
            ->orderBy($sort, $dir)
            ->paginate(10)->withQueryString();

        return view('users.index', compact('users', 'sort', 'dir'));
    }

    public function create()
    {
        return view('users.form', ['user' => new User(['role' => User::ROLE_KASIR, 'is_active' => true])]);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'name'     => ['required', 'string', 'max:80'],
            'email'    => ['required', 'email', 'max:255', 'unique:users,email'],
            'role'     => ['required', Rule::in(User::ROLES)],
            'password' => ['required', 'string', 'min:8', 'confirmed'],
        ]);
        $data['is_active'] = $request->boolean('is_active');
        User::create($data);

        return redirect()->route('users.index')->with('status', 'Akun berhasil ditambahkan.');
    }

    public function edit(User $user)
    {
        return view('users.form', compact('user'));
    }

    public function update(Request $request, User $user)
    {
        $data = $request->validate([
            'name'     => ['required', 'string', 'max:80'],
            'email'    => ['required', 'email', 'max:255', Rule::unique('users', 'email')->ignore($user)],
            'role'     => ['required', Rule::in(User::ROLES)],
            'password' => ['nullable', 'string', 'min:8', 'confirmed'],
        ]);
        $data['is_active'] = $request->boolean('is_active');
        if (blank($data['password'] ?? null)) {
            unset($data['password']);
        }

        // Cegah admin mengunci dirinya sendiri
        if ($user->is($request->user()) && ($data['role'] !== User::ROLE_ADMIN || ! $data['is_active'])) {
            return back()->withInput()->with('error', 'Anda tidak dapat menurunkan role atau menonaktifkan akun Anda sendiri.');
        }
        if ($this->isLastAdmin($user) && ($data['role'] !== User::ROLE_ADMIN || ! $data['is_active'])) {
            return back()->withInput()->with('error', 'Minimal harus ada satu Admin aktif.');
        }

        $user->update($data);

        return redirect()->route('users.index')->with('status', 'Akun berhasil diperbarui.');
    }

    public function destroy(Request $request, User $user)
    {
        if ($user->is($request->user())) {
            return back()->with('error', 'Anda tidak dapat menghapus akun sendiri.');
        }
        if ($this->isLastAdmin($user)) {
            return back()->with('error', 'Minimal harus ada satu Admin aktif.');
        }
        if ($user->sales()->exists()) {
            return back()->with('error', 'Akun sudah memiliki riwayat transaksi. Nonaktifkan saja akunnya.');
        }
        $user->delete();

        return back()->with('status', 'Akun berhasil dihapus.');
    }

    private function isLastAdmin(User $user): bool
    {
        return $user->isAdmin() && $user->is_active
            && User::where('role', User::ROLE_ADMIN)->where('is_active', true)->count() <= 1;
    }
}
