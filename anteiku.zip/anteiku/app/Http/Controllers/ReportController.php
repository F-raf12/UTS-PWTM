<?php

namespace App\Http\Controllers;

use App\Models\Sale;
use App\Models\SaleDetail;
use App\Models\User;
use Barryvdh\DomPDF\Facade\Pdf;
use Carbon\Carbon;
use Illuminate\Http\Request;

class ReportController extends Controller
{
    public function index(Request $request)
    {
        $data = $this->build($request);
        $data['sales'] = $this->query($data['from'], $data['to'], $request)
            ->with(['customer', 'user'])->withSum('details as items_count', 'qty')
            ->latest('sold_at')->paginate(10)->withQueryString();
        $data['cashiers'] = User::orderBy('name')->get();

        return view('reports.index', $data);
    }

    public function pdf(Request $request)
    {
        $data = $this->build($request);
        $data['sales'] = $this->query($data['from'], $data['to'], $request)
            ->with(['customer', 'user'])->withSum('details as items_count', 'qty')->latest('sold_at')->get();

        return Pdf::loadView('reports.pdf', $data)->setPaper('a4')
            ->download('laporan-penjualan-' . $data['from']->format('Ymd') . '-' . $data['to']->format('Ymd') . '.pdf');
    }

    private function query(Carbon $from, Carbon $to, Request $request)
    {
        return Sale::completed()
            ->whereBetween('sold_at', [$from->copy()->startOfDay(), $to->copy()->endOfDay()])
            ->when($request->cashier, fn ($q, $u) => $q->where('user_id', $u))
            ->when($request->payment, fn ($q, $m) => $q->where('payment_method', $m));
    }

    private function build(Request $request): array
    {
        $request->validate([
            'from' => ['nullable', 'date'],
            'to'   => ['nullable', 'date', 'after_or_equal:from'],
        ]);
        $from = $request->filled('from') ? Carbon::parse($request->from) : now()->startOfMonth();
        $to   = $request->filled('to') ? Carbon::parse($request->to) : now();

        $base = fn () => $this->query($from, $to, $request);

        $count = $base()->count();
        $revenue = (int) $base()->sum('total');
        $items = (int) SaleDetail::whereIn('sale_id', $base()->select('sales.id'))->sum('qty');

        $daily = $base()->get(['sold_at', 'total'])
            ->groupBy(fn ($s) => $s->sold_at->toDateString())->sortKeys()
            ->map(fn ($g) => ['count' => $g->count(), 'total' => $g->sum('total')]);

        $topProducts = SaleDetail::selectRaw('product_name, SUM(qty) as qty, SUM(subtotal) as revenue')
            ->whereIn('sale_id', $base()->select('sales.id'))
            ->groupBy('product_name')->orderByDesc('qty')->limit(10)->get();

        return [
            'from' => $from, 'to' => $to,
            'summary' => ['revenue' => $revenue, 'count' => $count, 'items' => $items, 'average' => $count ? (int) round($revenue / $count) : 0],
            'daily' => $daily, 'topProducts' => $topProducts,
            'dailyMax' => max(1, (int) $daily->max('total')),
        ];
    }
}
