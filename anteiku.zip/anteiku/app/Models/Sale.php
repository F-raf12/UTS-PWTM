<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Sale extends Model
{
    public const COMPLETED = 'completed';
    public const CANCELLED = 'cancelled';
    public const METHODS = ['tunai' => 'Tunai', 'qris' => 'QRIS', 'debit' => 'Kartu Debit'];

    protected $fillable = [
        'invoice_no', 'user_id', 'customer_id', 'sold_at', 'total', 'paid',
        'change_amount', 'payment_method', 'status', 'notes',
    ];

    protected function casts(): array
    {
        return ['sold_at' => 'datetime', 'total' => 'integer', 'paid' => 'integer', 'change_amount' => 'integer'];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function customer(): BelongsTo
    {
        return $this->belongsTo(Customer::class);
    }

    public function details(): HasMany
    {
        return $this->hasMany(SaleDetail::class);
    }

    public function scopeCompleted(Builder $q): Builder
    {
        return $q->where('status', self::COMPLETED);
    }

    /** Admin melihat semua transaksi, Kasir hanya transaksinya sendiri. */
    public function scopeVisibleTo(Builder $q, User $user): Builder
    {
        return $user->isAdmin() ? $q : $q->where('user_id', $user->id);
    }

    public function getMethodLabelAttribute(): string
    {
        return self::METHODS[$this->payment_method] ?? $this->payment_method;
    }

    public static function generateInvoiceNo(): string
    {
        $prefix = 'ANT-' . now()->format('Ymd') . '-';
        $last = static::where('invoice_no', 'like', $prefix . '%')->orderByDesc('invoice_no')->value('invoice_no');
        $next = $last ? ((int) substr($last, -4)) + 1 : 1;

        return $prefix . str_pad((string) $next, 4, '0', STR_PAD_LEFT);
    }
}
