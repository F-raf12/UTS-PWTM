# Anteiku - Sistem Penjualan Coffee & Dessert Shop

Aplikasi penjualan internal untuk kedai kopi **Anteiku** (Laravel 12, MySQL, Blade, Bootstrap 5).
Project ini adalah hasil modifikasi dari project website top-up lama: kerangka Laravel, konfigurasi,
tabel `users`/`sessions`/`cache`/`jobs`, pola autentikasi, dan DomPDF dipertahankan; seluruh logika top-up
(Order, Package, Supplier, QRIS, Discord bot, dll.) diganti dengan modul coffee shop.

## Cara menjalankan (lokal)
Syarat: PHP 8.2+ (ekstensi pdo_mysql, mbstring, gd, fileinfo), Composer 2, MySQL/MariaDB (mis. XAMPP).

```bash
composer install
# buat database kosong bernama "anteiku" (phpMyAdmin / mysql)
#   CREATE DATABASE anteiku CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
# sesuaikan DB_USERNAME / DB_PASSWORD di file .env bila perlu (default: root, tanpa password)
php artisan key:generate      # hanya jika APP_KEY di .env kosong
php artisan migrate:fresh --seed
php artisan storage:link      # agar gambar produk tampil
php artisan serve             # buka http://127.0.0.1:8000
```

## Akun demo (password: `password`)
| Role  | Email                |
|-------|----------------------|
| Admin | admin@anteiku.test   |
| Kasir | kasir@anteiku.test   |
| Kasir | kasir2@anteiku.test  |

## Hak akses
| Fitur                                   | Admin | Kasir |
|-----------------------------------------|:-----:|:-----:|
| Dashboard                               | semua data | hanya transaksi miliknya |
| Transaksi baru (POS)                    | ✔ | ✔ |
| Riwayat transaksi                       | semua | hanya miliknya |
| Batalkan transaksi (stok dikembalikan)  | ✔ | ✘ |
| Produk                                  | CRUD | lihat saja |
| Kategori                                | CRUD | ✘ |
| Pelanggan                               | CRUD | tambah / ubah / lihat |
| Laporan penjualan + PDF                 | ✔ | ✘ |
| Manajemen user                          | ✔ | ✘ |

Dijaga oleh middleware `auth`, `active` (akun nonaktif otomatis keluar) dan `role:admin` (lihat `routes/web.php`).

## Database (6 tabel + relasi)
```
users 1─∞ sales            (sales.user_id        -> kasir yang melayani)
customers 1─∞ sales        (sales.customer_id    -> nullable, null = pelanggan umum)
sales 1─∞ sale_details     (cascade delete)
products 1─∞ sale_details  (restrict)
categories 1─∞ products    (restrict)
```
`sale_details` menyimpan snapshot nama & harga produk saat transaksi, sehingga riwayat tidak berubah
walau harga produk diubah kemudian. Harga selalu dihitung ulang di server dari database.

## Struktur penting
- `app/Models` - User, Category, Product, Customer, Sale, SaleDetail (relasi Eloquent)
- `app/Http/Controllers` - Auth, Dashboard, Category, Product, Customer, Sale, Report, User
- `app/Http/Middleware` - `CheckRole`, `EnsureUserActive` (alias di `bootstrap/app.php`)
- `database/migrations`, `database/seeders/DatabaseSeeder.php` - skema + data contoh (116 transaksi 30 hari)
- `resources/views` - layout, dashboard, CRUD, POS, laporan; `public/css/anteiku.css` - tema
- `public/vendor` - Bootstrap 5 & Bootstrap Icons (lokal, tidak butuh CDN)
- `tests/Feature/AnteikuTest.php` - 14 tes otomatis (`php artisan test`)
