@props(['col', 'sort', 'dir'])
@php
    $active = $sort === $col;
    $next = $active && $dir === 'asc' ? 'desc' : 'asc';
@endphp
<a href="{{ request()->fullUrlWithQuery(['sort' => $col, 'dir' => $next, 'page' => null]) }}">
    {{ $slot }}
    <i class="bi {{ $active ? ($dir === 'asc' ? 'bi-sort-up' : 'bi-sort-down') : 'bi-arrow-down-up opacity-25' }}"></i>
</a>
