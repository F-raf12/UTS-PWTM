@props(['action', 'message' => 'Yakin ingin menghapus data ini?'])
<form method="POST" action="{{ $action }}" class="d-inline" data-confirm="{{ $message }}">
    @csrf @method('DELETE')
    <button class="btn btn-sm btn-outline-danger" type="submit" title="Hapus"><i class="bi bi-trash3"></i></button>
</form>
