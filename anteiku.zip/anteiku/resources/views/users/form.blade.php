@extends('layouts.app')
@php($edit = $user->exists)
@section('title', $edit ? 'Ubah User' : 'Tambah User')
@section('heading', $edit ? 'Ubah User' : 'Tambah User')
@section('content')
<div class="card" style="max-width:700px"><div class="card-body p-4">
    <form method="POST" action="{{ $edit ? route('users.update', $user) : route('users.store') }}" novalidate>
        @csrf @if($edit) @method('PUT') @endif
        <div class="row g-3">
            <div class="col-md-6">
                <label class="form-label" for="name">Nama <span class="text-danger">*</span></label>
                <input id="name" name="name" value="{{ old('name', $user->name) }}" class="form-control @error('name') is-invalid @enderror" maxlength="80" required>
                @error('name')<div class="invalid-feedback">{{ $message }}</div>@enderror
            </div>
            <div class="col-md-6">
                <label class="form-label" for="email">Email <span class="text-danger">*</span></label>
                <input id="email" type="email" name="email" value="{{ old('email', $user->email) }}" class="form-control @error('email') is-invalid @enderror" required>
                @error('email')<div class="invalid-feedback">{{ $message }}</div>@enderror
            </div>
            <div class="col-md-6">
                <label class="form-label" for="role">Role <span class="text-danger">*</span></label>
                <select id="role" name="role" class="form-select @error('role') is-invalid @enderror" required>
                    <option value="kasir" @selected(old('role', $user->role) == 'kasir')>Kasir</option>
                    <option value="admin" @selected(old('role', $user->role) == 'admin')>Admin</option>
                </select>
                @error('role')<div class="invalid-feedback">{{ $message }}</div>@enderror
            </div>
            <div class="col-md-6 d-flex align-items-end">
                <div class="form-check form-switch mb-2">
                    <input class="form-check-input" type="checkbox" role="switch" name="is_active" value="1" id="is_active" @checked(old('is_active', $user->is_active))>
                    <label class="form-check-label" for="is_active">Akun aktif</label>
                </div>
            </div>
            <div class="col-md-6">
                <label class="form-label" for="password">Password @unless($edit)<span class="text-danger">*</span>@endunless</label>
                <input id="password" type="password" name="password" class="form-control @error('password') is-invalid @enderror" autocomplete="new-password" @unless($edit) required @endunless>
                <small class="text-muted">{{ $edit ? 'Kosongkan jika tidak ingin mengubah password.' : 'Minimal 8 karakter.' }}</small>
                @error('password')<div class="invalid-feedback">{{ $message }}</div>@enderror
            </div>
            <div class="col-md-6">
                <label class="form-label" for="password_confirmation">Konfirmasi Password</label>
                <input id="password_confirmation" type="password" name="password_confirmation" class="form-control" autocomplete="new-password">
            </div>
        </div>
        <div class="mt-4">
            <button class="btn btn-primary"><i class="bi bi-check-lg"></i> Simpan</button>
            <a href="{{ route('users.index') }}" class="btn btn-link">Batal</a>
        </div>
    </form>
</div></div>
@endsection
