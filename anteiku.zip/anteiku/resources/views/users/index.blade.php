@extends('layouts.app')
@section('title', 'Manajemen User')
@section('heading', 'Manajemen User')
@section('content')
<div class="card">
    <div class="filter-bar">
        <form class="row g-2 align-items-center auto-submit" method="GET">
            <div class="col-lg-4 col-md-6"><div class="input-group"><span class="input-group-text"><i class="bi bi-search"></i></span>
                <input type="search" name="q" value="{{ request('q') }}" class="form-control" placeholder="Cari nama atau email..."></div></div>
            <div class="col-lg-2 col-6"><select name="role" class="form-select">
                <option value="">Semua role</option><option value="admin" @selected(request('role') == 'admin')>Admin</option><option value="kasir" @selected(request('role') == 'kasir')>Kasir</option>
            </select></div>
            <div class="col-lg-2 col-6"><select name="status" class="form-select">
                <option value="">Semua status</option><option value="active" @selected(request('status') == 'active')>Aktif</option><option value="inactive" @selected(request('status') == 'inactive')>Nonaktif</option>
            </select></div>
            <div class="col-auto"><button class="btn btn-soft">Cari</button>
                @if(request()->hasAny(['q','role','status','sort']))<a href="{{ route('users.index') }}" class="btn btn-link">Reset</a>@endif</div>
            <div class="col text-lg-end"><a href="{{ route('users.create') }}" class="btn btn-primary"><i class="bi bi-person-plus"></i> Tambah User</a></div>
        </form>
    </div>
    <div class="table-responsive">
        <table class="table">
            <thead><tr>
                <th><x-sort col="name" :sort="$sort" :dir="$dir">Nama</x-sort></th>
                <th><x-sort col="email" :sort="$sort" :dir="$dir">Email</x-sort></th>
                <th><x-sort col="role" :sort="$sort" :dir="$dir">Role</x-sort></th>
                <th>Status</th><th>Transaksi</th>
                <th class="text-end">Aksi</th>
            </tr></thead>
            <tbody>
            @forelse($users as $u)
                <tr>
                    <td><div class="d-flex align-items-center gap-2"><div class="avatar" style="width:34px;height:34px">{{ $u->initials }}</div>
                        <span class="fw-medium">{{ $u->name }}</span>@if($u->is(auth()->user()))<span class="badge-soft badge-brown">Anda</span>@endif</div></td>
                    <td>{{ $u->email }}</td>
                    <td><span class="badge-soft {{ $u->isAdmin() ? 'badge-warn' : 'badge-brown' }}">{{ $u->role_label }}</span></td>
                    <td>{!! $u->is_active ? '<span class="badge-soft badge-ok">Aktif</span>' : '<span class="badge-soft badge-bad">Nonaktif</span>' !!}</td>
                    <td>{{ $u->sales_count }}</td>
                    <td class="text-end text-nowrap">
                        <a href="{{ route('users.edit', $u) }}" class="btn btn-sm btn-soft" title="Ubah"><i class="bi bi-pencil"></i></a>
                        @unless($u->is(auth()->user()))<x-confirm-delete :action="route('users.destroy', $u)" message="Hapus akun {{ $u->name }}?" />@endunless
                    </td>
                </tr>
            @empty
                <tr><td colspan="6" class="empty"><i class="bi bi-person-x"></i>User tidak ditemukan.</td></tr>
            @endforelse
            </tbody>
        </table>
    </div>
    @if($users->hasPages())<div class="card-footer bg-transparent d-flex justify-content-between align-items-center flex-wrap gap-2">
        <small class="text-muted">Menampilkan {{ $users->firstItem() }}-{{ $users->lastItem() }} dari {{ $users->total() }}</small>{{ $users->links() }}</div>@endif
</div>
@endsection
