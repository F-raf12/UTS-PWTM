@if(session('status'))
    <div class="alert alert-success border-0 shadow-sm alert-dismissible fade show" role="alert" style="background:#e1f0e6;color:#2f6e46">
        <i class="bi bi-check-circle-fill me-1"></i> {{ session('status') }}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
@endif
@if(session('error'))
    <div class="alert alert-danger border-0 shadow-sm alert-dismissible fade show" role="alert" style="background:#f8e1de;color:#9b3328">
        <i class="bi bi-exclamation-triangle-fill me-1"></i> {{ session('error') }}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
@endif
