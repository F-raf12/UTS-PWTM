@extends('layouts.app')
@php($edit = $category->exists)
@section('title', $edit ? 'Ubah Kategori' : 'Tambah Kategori')
@section('heading', $edit ? 'Ubah Kategori' : 'Tambah Kategori')
@section('content')
<div class="card" style="max-width:640px"><div class="card-body p-4">
    <form method="POST" action="{{ $edit ? route('categories.update', $category) : route('categories.store') }}" novalidate>
        @csrf @if($edit) @method('PUT') @endif
        <div class="mb-3">
            <label class="form-label" for="name">Nama Kategori <span class="text-danger">*</span></label>
            <input id="name" name="name" value="{{ old('name', $category->name) }}" class="form-control @error('name') is-invalid @enderror" maxlength="80" required>
            @error('name')<div class="invalid-feedback">{{ $message }}</div>@enderror
        </div>
        <div class="mb-4">
            <label class="form-label" for="description">Deskripsi</label>
            <textarea id="description" name="description" rows="3" class="form-control @error('description') is-invalid @enderror" maxlength="255">{{ old('description', $category->description) }}</textarea>
            @error('description')<div class="invalid-feedback">{{ $message }}</div>@enderror
        </div>
        <button class="btn btn-primary"><i class="bi bi-check-lg"></i> Simpan</button>
        <a href="{{ route('categories.index') }}" class="btn btn-link">Batal</a>
    </form>
</div></div>
@endsection
