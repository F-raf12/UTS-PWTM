@extends('layouts.app')
@section('title', 'Kategori')
@section('heading', 'Kategori Produk')
@section('content')
<div class="card">
    <div class="filter-bar">
        <form class="row g-2 align-items-center" method="GET">
            <div class="col-md-5"><div class="input-group"><span class="input-group-text"><i class="bi bi-search"></i></span>
                <input type="search" name="q" value="{{ request('q') }}" class="form-control" placeholder="Cari kategori..."></div></div>
            <div class="col-auto"><button class="btn btn-soft">Cari</button>
                @if(request()->hasAny(['q','sort']))<a href="{{ route('categories.index') }}" class="btn btn-link">Reset</a>@endif</div>
            <div class="col text-md-end"><a href="{{ route('categories.create') }}" class="btn btn-primary"><i class="bi bi-plus-lg"></i> Tambah Kategori</a></div>
        </form>
    </div>
    <div class="table-responsive">
        <table class="table">
            <thead><tr>
                <th>#</th>
                <th><x-sort col="name" :sort="$sort" :dir="$dir">Nama</x-sort></th>
                <th>Deskripsi</th>
                <th><x-sort col="products_count" :sort="$sort" :dir="$dir">Jumlah Produk</x-sort></th>
                <th class="text-end">Aksi</th>
            </tr></thead>
            <tbody>
            @forelse($categories as $c)
                <tr>
                    <td>{{ $categories->firstItem() + $loop->index }}</td>
                    <td class="fw-medium">{{ $c->name }}</td>
                    <td class="text-muted">{{ $c->description ?: '-' }}</td>
                    <td><span class="badge-soft badge-brown">{{ $c->products_count }} produk</span></td>
                    <td class="text-end text-nowrap">
                        <a href="{{ route('categories.edit', $c) }}" class="btn btn-sm btn-soft" title="Ubah"><i class="bi bi-pencil"></i></a>
                        <x-confirm-delete :action="route('categories.destroy', $c)" message="Hapus kategori {{ $c->name }}?" />
                    </td>
                </tr>
            @empty
                <tr><td colspan="5" class="empty"><i class="bi bi-tags"></i>Belum ada kategori.</td></tr>
            @endforelse
            </tbody>
        </table>
    </div>
    @if($categories->hasPages())<div class="card-footer bg-transparent d-flex justify-content-between align-items-center">
        <small class="text-muted">Menampilkan {{ $categories->firstItem() }}-{{ $categories->lastItem() }} dari {{ $categories->total() }}</small>{{ $categories->links() }}</div>@endif
</div>
@endsection
