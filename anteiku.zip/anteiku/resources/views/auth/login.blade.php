<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Masuk - Anteiku</title>
    @include('partials.head')
</head>
<body>
<div class="login-wrap">
    <section class="login-art">
        <div class="brand mb-0">
            <span class="brand-icon"><i class="bi bi-cup-hot-fill"></i></span>
            <span><span class="brand-name">Anteiku</span><small>Coffee &amp; Dessert Shop</small></span>
        </div>
        <div>
            <h2 class="serif">Secangkir kehangatan, setiap hari.</h2>
            <p>Sistem penjualan internal Anteiku untuk mencatat transaksi, mengelola menu, dan memantau laporan penjualan.</p>
        </div>
        <small style="color:#bda58c">&copy; {{ date('Y') }} Anteiku Coffee &amp; Dessert</small>
    </section>

    <section class="login-form">
        <div class="login-card">
            <h3 class="serif mb-1">Selamat datang</h3>
            <p class="text-muted mb-4">Masuk dengan akun Admin atau Kasir.</p>

            @if(session('status'))<div class="alert alert-success border-0 py-2">{{ session('status') }}</div>@endif
            @if($errors->any())<div class="alert alert-danger border-0 py-2">{{ $errors->first() }}</div>@endif

            <form method="POST" action="{{ route('login') }}" novalidate>
                @csrf
                <div class="mb-3">
                    <label class="form-label" for="email">Email</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-envelope"></i></span>
                        <input id="email" type="email" name="email" value="{{ old('email') }}" class="form-control @error('email') is-invalid @enderror" placeholder="nama@anteiku.test" required autofocus>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label" for="password">Password</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-lock"></i></span>
                        <input id="password" type="password" name="password" class="form-control @error('password') is-invalid @enderror" placeholder="••••••••" required>
                    </div>
                </div>
                <div class="form-check mb-4">
                    <input class="form-check-input" type="checkbox" name="remember" id="remember">
                    <label class="form-check-label" for="remember">Ingat saya</label>
                </div>
                <button class="btn btn-primary w-100 py-2" type="submit"><i class="bi bi-box-arrow-in-right me-1"></i> Masuk</button>
            </form>
        </div>
    </section>
</div>
@include('partials.scripts')
</body>
</html>
