<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Dashboard') - Anteiku</title>
    @include('partials.head')
</head>
<body>
@php($u = auth()->user())
<aside class="sidebar" id="sidebar">
    <a href="{{ route('dashboard') }}" class="brand">
        <span class="brand-icon"><i class="bi bi-cup-hot-fill"></i></span>
        <span><span class="brand-name">Anteiku</span><small>Coffee &amp; Dessert</small></span>
    </a>

    <nav>
        <a href="{{ route('dashboard') }}" class="side-link {{ request()->routeIs('dashboard') ? 'active' : '' }}"><i class="bi bi-grid-1x2-fill"></i> Dashboard</a>

        <div class="nav-label">Penjualan</div>
        <a href="{{ route('sales.create') }}" class="side-link {{ request()->routeIs('sales.create') ? 'active' : '' }}"><i class="bi bi-bag-plus-fill"></i> Transaksi Baru</a>
        <a href="{{ route('sales.index') }}" class="side-link {{ request()->routeIs('sales.index', 'sales.show') ? 'active' : '' }}"><i class="bi bi-receipt"></i> Riwayat Transaksi</a>

        <div class="nav-label">Data Master</div>
        <a href="{{ route('products.index') }}" class="side-link {{ request()->routeIs('products.*') ? 'active' : '' }}"><i class="bi bi-cup-straw"></i> Produk</a>
        @if($u->isAdmin())
            <a href="{{ route('categories.index') }}" class="side-link {{ request()->routeIs('categories.*') ? 'active' : '' }}"><i class="bi bi-tags-fill"></i> Kategori</a>
        @endif
        <a href="{{ route('customers.index') }}" class="side-link {{ request()->routeIs('customers.*') ? 'active' : '' }}"><i class="bi bi-people-fill"></i> Pelanggan</a>

        @if($u->isAdmin())
            <div class="nav-label">Administrasi</div>
            <a href="{{ route('reports.index') }}" class="side-link {{ request()->routeIs('reports.*') ? 'active' : '' }}"><i class="bi bi-bar-chart-line-fill"></i> Laporan Penjualan</a>
            <a href="{{ route('users.index') }}" class="side-link {{ request()->routeIs('users.*') ? 'active' : '' }}"><i class="bi bi-person-gear"></i> Manajemen User</a>
        @endif
    </nav>

    <div class="side-user mt-4">
        <div class="avatar">{{ $u->initials }}</div>
        <div class="flex-grow-1 overflow-hidden">
            <div class="text-white fw-medium text-truncate">{{ $u->name }}</div>
            <small style="color:#bda58c">{{ $u->role_label }}</small>
        </div>
        <form method="POST" action="{{ route('logout') }}">@csrf
            <button class="btn btn-sm text-white-50 p-1" title="Keluar" type="submit"><i class="bi bi-box-arrow-right fs-5"></i></button>
        </form>
    </div>
</aside>

<div class="main">
    <header class="topbar">
        <button class="btn btn-soft d-lg-none" id="sidebarToggle" type="button" aria-label="Menu"><i class="bi bi-list fs-5"></i></button>
        <h1 class="flex-grow-1">@yield('heading', 'Dashboard')</h1>
        <span class="text-muted d-none d-md-inline"><i class="bi bi-calendar3"></i> {{ now()->translatedFormat('l, d F Y') }}</span>
    </header>

    <main class="content">
        @include('partials.flash')
        @yield('content')
    </main>
</div>

@include('partials.scripts')
@stack('scripts')
</body>
</html>
