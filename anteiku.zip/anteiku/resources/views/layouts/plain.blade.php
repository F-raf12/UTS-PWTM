<!DOCTYPE html>
<html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>@yield('title') - Anteiku</title>@include('partials.head')</head>
<body><div class="container py-5" style="max-width:560px">@yield('content')</div></body></html>
