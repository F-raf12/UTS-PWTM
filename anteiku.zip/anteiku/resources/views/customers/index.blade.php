@extends('layouts.app')
@section('title', 'Pelanggan')
@section('heading', 'Pelanggan')
@section('content')
@php($admin = auth()->user()->isAdmin())
<div class="card">
    <div class="filter-bar">
        <form class="row g-2 align-items-center auto-submit" method="GET">
            <div class="col-lg-4 col-md-6"><div class="input-group"><span class="input-group-text"><i class="bi bi-search"></i></span>
                <input type="search" name="q" value="{{ request('q') }}" class="form-control" placeholder="Cari nama, telepon, email..."></div></div>
            <div class="col-lg-2 col-6"><select name="filter" class="form-select">
                <option value="">Semua pelanggan</option>
                <option value="buyer" @selected(request('filter') == 'buyer')>Pernah membeli</option>
                <option value="new" @selected(request('filter') == 'new')>Belum pernah membeli</option>
            </select></div>
            <div class="col-auto"><button class="btn btn-soft">Cari</button>
                @if(request()->hasAny(['q','filter','sort']))<a href="{{ route('customers.index') }}" class="btn btn-link">Reset</a>@endif</div>
            <div class="col text-lg-end"><a href="{{ route('customers.create') }}" class="btn btn-primary"><i class="bi bi-plus-lg"></i> Tambah Pelanggan</a></div>
        </form>
    </div>
    <div class="table-responsive">
        <table class="table">
            <thead><tr>
                <th>#</th>
                <th><x-sort col="name" :sort="$sort" :dir="$dir">Nama</x-sort></th>
                <th><x-sort col="phone" :sort="$sort" :dir="$dir">Telepon</x-sort></th>
                <th>Email</th><th>Alamat</th>
                <th><x-sort col="sales_count" :sort="$sort" :dir="$dir">Transaksi</x-sort></th>
                <th class="text-end">Aksi</th>
            </tr></thead>
            <tbody>
            @forelse($customers as $c)
                <tr>
                    <td>{{ $customers->firstItem() + $loop->index }}</td>
                    <td class="fw-medium">{{ $c->name }}</td>
                    <td>{{ $c->phone ?: '-' }}</td>
                    <td>{{ $c->email ?: '-' }}</td>
                    <td class="text-muted">{{ \Illuminate\Support\Str::limit($c->address, 30) ?: '-' }}</td>
                    <td><span class="badge-soft badge-brown">{{ $c->sales_count }}x</span></td>
                    <td class="text-end text-nowrap">
                        <a href="{{ route('customers.edit', $c) }}" class="btn btn-sm btn-soft" title="Ubah"><i class="bi bi-pencil"></i></a>
                        @if($admin)<x-confirm-delete :action="route('customers.destroy', $c)" message="Hapus pelanggan {{ $c->name }}?" />@endif
                    </td>
                </tr>
            @empty
                <tr><td colspan="7" class="empty"><i class="bi bi-people"></i>Pelanggan tidak ditemukan.</td></tr>
            @endforelse
            </tbody>
        </table>
    </div>
    @if($customers->hasPages())<div class="card-footer bg-transparent d-flex justify-content-between align-items-center flex-wrap gap-2">
        <small class="text-muted">Menampilkan {{ $customers->firstItem() }}-{{ $customers->lastItem() }} dari {{ $customers->total() }}</small>{{ $customers->links() }}</div>@endif
</div>
@endsection
