@extends('layouts.app')
@php($edit = $customer->exists)
@section('title', $edit ? 'Ubah Pelanggan' : 'Tambah Pelanggan')
@section('heading', $edit ? 'Ubah Pelanggan' : 'Tambah Pelanggan')
@section('content')
<div class="card" style="max-width:700px"><div class="card-body p-4">
    <form method="POST" action="{{ $edit ? route('customers.update', $customer) : route('customers.store') }}" novalidate>
        @csrf @if($edit) @method('PUT') @endif
        <div class="row g-3">
            <div class="col-12">
                <label class="form-label" for="name">Nama <span class="text-danger">*</span></label>
                <input id="name" name="name" value="{{ old('name', $customer->name) }}" class="form-control @error('name') is-invalid @enderror" maxlength="100" required>
                @error('name')<div class="invalid-feedback">{{ $message }}</div>@enderror
            </div>
            <div class="col-md-6">
                <label class="form-label" for="phone">No. Telepon</label>
                <input id="phone" name="phone" value="{{ old('phone', $customer->phone) }}" class="form-control @error('phone') is-invalid @enderror" placeholder="08xxxxxxxxxx">
                @error('phone')<div class="invalid-feedback">{{ $message }}</div>@enderror
            </div>
            <div class="col-md-6">
                <label class="form-label" for="email">Email</label>
                <input id="email" type="email" name="email" value="{{ old('email', $customer->email) }}" class="form-control @error('email') is-invalid @enderror">
                @error('email')<div class="invalid-feedback">{{ $message }}</div>@enderror
            </div>
            <div class="col-12">
                <label class="form-label" for="address">Alamat</label>
                <input id="address" name="address" value="{{ old('address', $customer->address) }}" class="form-control @error('address') is-invalid @enderror" maxlength="255">
                @error('address')<div class="invalid-feedback">{{ $message }}</div>@enderror
            </div>
        </div>
        <div class="mt-4">
            <button class="btn btn-primary"><i class="bi bi-check-lg"></i> Simpan</button>
            <a href="{{ route('customers.index') }}" class="btn btn-link">Batal</a>
        </div>
    </form>
</div></div>
@endsection
