@extends('layouts.app')
@section('title', 'Dashboard')
@section('heading', 'Dashboard')

@section('content')
<div class="hero mb-4">
    <h2>Halo, {{ auth()->user()->name }} ☕</h2>
    <p>
        @if(auth()->user()->isAdmin()) Ringkasan seluruh penjualan Anteiku hari ini.
        @else Ringkasan transaksi yang Anda layani. Semangat melayani!@endif
    </p>
</div>

<div class="row g-3 mb-4">
    <div class="col-sm-6 col-xl-3"><div class="card stat">
        <div class="stat-icon c1"><i class="bi bi-cash-coin"></i></div>
        <div><div class="label">Total Penjualan</div><div class="value">@rp($totalSales)</div><small class="text-muted">Bulan ini @rp($monthSales)</small></div>
    </div></div>
    <div class="col-sm-6 col-xl-3"><div class="card stat">
        <div class="stat-icon c2"><i class="bi bi-receipt-cutoff"></i></div>
        <div><div class="label">Jumlah Transaksi</div><div class="value">{{ number_format($saleCount, 0, ',', '.') }}</div><small class="text-muted">Hari ini {{ $todayCount }} transaksi</small></div>
    </div></div>
    <div class="col-sm-6 col-xl-3"><div class="card stat">
        <div class="stat-icon c3"><i class="bi bi-cup-hot"></i></div>
        <div><div class="label">Jumlah Produk</div><div class="value">{{ $productCount }}</div><small class="text-muted">{{ $lowStock->count() }} stok menipis</small></div>
    </div></div>
    <div class="col-sm-6 col-xl-3"><div class="card stat">
        <div class="stat-icon c4"><i class="bi bi-people"></i></div>
        <div><div class="label">Pelanggan</div><div class="value">{{ $customerCount }}</div><small class="text-muted">Hari ini @rp($todaySales)</small></div>
    </div></div>
</div>

<div class="row g-3 mb-3">
    <div class="col-lg-8">
        <div class="card h-100">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span>Penjualan 7 Hari Terakhir</span>
                <a href="{{ route('sales.create') }}" class="btn btn-sm btn-primary"><i class="bi bi-plus-lg"></i> Transaksi Baru</a>
            </div>
            <div class="card-body">
                <div class="bars">
                    @foreach($chart as $c)
                        <div class="bar-col" title="{{ $c['date'] }}: Rp {{ number_format($c['total'], 0, ',', '.') }}">
                            <div class="bar-val">{{ $c['total'] ? number_format($c['total'] / 1000, 0, ',', '.') . 'k' : '0' }}</div>
                            <div class="bar" style="height:{{ max(2, round($c['total'] / $chartMax * 100)) }}%"></div>
                            <div class="bar-lbl">{{ $c['label'] }}</div>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="card h-100">
            <div class="card-header"><i class="bi bi-fire text-danger"></i> Produk Terlaris</div>
            <ul class="list-group list-group-flush">
                @forelse($bestSellers as $i => $b)
                    <li class="list-group-item d-flex align-items-center gap-3 py-3">
                        <span class="badge-soft badge-brown">{{ $i + 1 }}</span>
                        <div class="flex-grow-1"><div class="fw-medium">{{ $b->product_name }}</div><small class="text-muted">@rp($b->revenue)</small></div>
                        <strong>{{ $b->qty }}x</strong>
                    </li>
                @empty
                    <li class="list-group-item empty border-0">Belum ada penjualan.</li>
                @endforelse
            </ul>
        </div>
    </div>
</div>

<div class="row g-3">
    <div class="col-lg-8">
        <div class="card">
            <div class="card-header d-flex justify-content-between"><span>Transaksi Terbaru</span><a href="{{ route('sales.index') }}" class="small">Lihat semua</a></div>
            <div class="table-responsive">
                <table class="table">
                    <thead><tr><th>Invoice</th><th>Pelanggan</th><th>Waktu</th><th class="text-end">Total</th></tr></thead>
                    <tbody>
                    @forelse($recent as $s)
                        <tr>
                            <td><a href="{{ route('sales.show', $s) }}" class="fw-medium">{{ $s->invoice_no }}</a>
                                @if($s->status === 'cancelled')<span class="badge-soft badge-bad ms-1">Batal</span>@endif</td>
                            <td>{{ $s->customer->name ?? 'Umum' }}</td>
                            <td class="text-muted">{{ $s->sold_at->translatedFormat('d M, H:i') }}</td>
                            <td class="text-end fw-medium">@rp($s->total)</td>
                        </tr>
                    @empty
                        <tr><td colspan="4" class="empty">Belum ada transaksi.</td></tr>
                    @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="card">
            <div class="card-header"><i class="bi bi-exclamation-triangle text-warning"></i> Stok Menipis</div>
            <ul class="list-group list-group-flush">
                @forelse($lowStock as $p)
                    <li class="list-group-item d-flex justify-content-between align-items-center py-3">
                        <span>{{ $p->name }}</span>
                        <span class="badge-soft {{ $p->stock == 0 ? 'badge-bad' : 'badge-warn' }}">{{ $p->stock == 0 ? 'Habis' : 'Sisa ' . $p->stock }}</span>
                    </li>
                @empty
                    <li class="list-group-item empty border-0">Semua stok aman 👍</li>
                @endforelse
            </ul>
        </div>
    </div>
</div>
@endsection
