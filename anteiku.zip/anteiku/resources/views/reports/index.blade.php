@extends('layouts.app')
@section('title', 'Laporan Penjualan')
@section('heading', 'Laporan Penjualan')
@section('content')
<div class="card mb-3"><div class="card-body">
    <form class="row g-2 align-items-end" method="GET">
        <div class="col-lg-2 col-6"><label class="form-label">Dari tanggal</label>
            <input type="date" name="from" value="{{ $from->toDateString() }}" class="form-control @error('from') is-invalid @enderror" required></div>
        <div class="col-lg-2 col-6"><label class="form-label">Sampai tanggal</label>
            <input type="date" name="to" value="{{ $to->toDateString() }}" class="form-control @error('to') is-invalid @enderror" required>
            @error('to')<div class="invalid-feedback">{{ $message }}</div>@enderror</div>
        <div class="col-lg-2 col-6"><label class="form-label">Kasir</label>
            <select name="cashier" class="form-select"><option value="">Semua</option>
            @foreach($cashiers as $c)<option value="{{ $c->id }}" @selected(request('cashier') == $c->id)>{{ $c->name }}</option>@endforeach</select></div>
        <div class="col-lg-2 col-6"><label class="form-label">Pembayaran</label>
            <select name="payment" class="form-select"><option value="">Semua</option>
            @foreach(\App\Models\Sale::METHODS as $k => $v)<option value="{{ $k }}" @selected(request('payment') == $k)>{{ $v }}</option>@endforeach</select></div>
        <div class="col-lg-4 d-flex gap-2 flex-wrap">
            <button class="btn btn-primary"><i class="bi bi-funnel"></i> Tampilkan</button>
            <a href="{{ route('reports.index') }}" class="btn btn-soft">Bulan ini</a>
            <a href="{{ route('reports.pdf', request()->query()) }}" class="btn btn-accent"><i class="bi bi-file-earmark-pdf"></i> Unduh PDF</a>
        </div>
    </form>
</div></div>

<div class="row g-3 mb-3">
    <div class="col-sm-6 col-xl-3"><div class="card stat"><div class="stat-icon c1"><i class="bi bi-cash-stack"></i></div>
        <div><div class="label">Total Pendapatan</div><div class="value">@rp($summary['revenue'])</div></div></div></div>
    <div class="col-sm-6 col-xl-3"><div class="card stat"><div class="stat-icon c2"><i class="bi bi-receipt"></i></div>
        <div><div class="label">Jumlah Transaksi</div><div class="value">{{ $summary['count'] }}</div></div></div></div>
    <div class="col-sm-6 col-xl-3"><div class="card stat"><div class="stat-icon c3"><i class="bi bi-cup-hot"></i></div>
        <div><div class="label">Item Terjual</div><div class="value">{{ $summary['items'] }}</div></div></div></div>
    <div class="col-sm-6 col-xl-3"><div class="card stat"><div class="stat-icon c4"><i class="bi bi-graph-up"></i></div>
        <div><div class="label">Rata-rata / Transaksi</div><div class="value">@rp($summary['average'])</div></div></div></div>
</div>

<div class="row g-3 mb-3">
    <div class="col-lg-7"><div class="card h-100">
        <div class="card-header">Penjualan per Hari</div>
        <div class="table-responsive" style="max-height:340px">
            <table class="table"><thead><tr><th>Tanggal</th><th>Transaksi</th><th class="text-end">Pendapatan</th><th style="width:30%"></th></tr></thead>
            <tbody>
            @forelse($daily as $date => $row)
                <tr><td>{{ \Carbon\Carbon::parse($date)->translatedFormat('D, d M Y') }}</td><td>{{ $row['count'] }}</td><td class="text-end fw-medium">@rp($row['total'])</td>
                    <td><div class="progress" style="height:8px"><div class="progress-bar" style="width:{{ round($row['total'] / $dailyMax * 100) }}%;background:var(--caramel)"></div></div></td></tr>
            @empty
                <tr><td colspan="4" class="empty">Tidak ada penjualan pada periode ini.</td></tr>
            @endforelse
            </tbody></table>
        </div>
    </div></div>
    <div class="col-lg-5"><div class="card h-100">
        <div class="card-header">Produk Terlaris</div>
        <div class="table-responsive"><table class="table"><thead><tr><th>Produk</th><th>Qty</th><th class="text-end">Pendapatan</th></tr></thead><tbody>
            @forelse($topProducts as $t)<tr><td>{{ $t->product_name }}</td><td>{{ $t->qty }}</td><td class="text-end">@rp($t->revenue)</td></tr>
            @empty<tr><td colspan="3" class="empty">Tidak ada data.</td></tr>@endforelse
        </tbody></table></div>
    </div></div>
</div>

<div class="card">
    <div class="card-header">Daftar Transaksi ({{ $from->translatedFormat('d M Y') }} - {{ $to->translatedFormat('d M Y') }})</div>
    <div class="table-responsive"><table class="table">
        <thead><tr><th>Invoice</th><th>Waktu</th><th>Pelanggan</th><th>Kasir</th><th>Pembayaran</th><th class="text-end">Total</th></tr></thead>
        <tbody>
        @forelse($sales as $s)
            <tr><td><a href="{{ route('sales.show', $s) }}" class="fw-medium">{{ $s->invoice_no }}</a></td><td class="text-muted">{{ $s->sold_at->translatedFormat('d M Y, H:i') }}</td>
                <td>{{ $s->customer->name ?? 'Umum' }}</td><td>{{ $s->user->name }}</td><td>{{ $s->method_label }}</td><td class="text-end fw-medium">@rp($s->total)</td></tr>
        @empty<tr><td colspan="6" class="empty">Tidak ada transaksi.</td></tr>@endforelse
        </tbody>
    </table></div>
    @if($sales->hasPages())<div class="card-footer bg-transparent d-flex justify-content-between align-items-center flex-wrap gap-2">
        <small class="text-muted">Menampilkan {{ $sales->firstItem() }}-{{ $sales->lastItem() }} dari {{ $sales->total() }}</small>{{ $sales->links() }}</div>@endif
</div>
@endsection
