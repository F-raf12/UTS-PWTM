<!DOCTYPE html>
<html lang="id"><head><meta charset="utf-8"><title>Laporan Penjualan Anteiku</title>
<style>
body{font-family:DejaVu Sans,sans-serif;font-size:10.5px;color:#2b211b}
h1{font-size:20px;margin:0;color:#2a1b14} h2{font-size:13px;margin:18px 0 6px;color:#6f4a33}
.sub{color:#8b7b6e;margin-bottom:12px}
table{width:100%;border-collapse:collapse}th,td{border:1px solid #e3d6c6;padding:5px 7px;text-align:left}
th{background:#ecdcc8;color:#2a1b14}.r{text-align:right}.sum td{border:0;padding:2px 0}
.head{border-bottom:3px solid #c08552;padding-bottom:8px;margin-bottom:10px}
</style></head><body>
<div class="head"><h1>Anteiku Coffee &amp; Dessert</h1><div>Laporan Penjualan</div></div>
<div class="sub">Periode: {{ $from->translatedFormat('d F Y') }} - {{ $to->translatedFormat('d F Y') }} &middot; Dicetak: {{ now()->translatedFormat('d F Y H:i') }}</div>

<h2>Ringkasan</h2>
<table class="sum">
<tr><td>Total pendapatan</td><td class="r"><b>@rp($summary['revenue'])</b></td></tr>
<tr><td>Jumlah transaksi</td><td class="r">{{ $summary['count'] }}</td></tr>
<tr><td>Item terjual</td><td class="r">{{ $summary['items'] }}</td></tr>
<tr><td>Rata-rata per transaksi</td><td class="r">@rp($summary['average'])</td></tr>
</table>

<h2>Penjualan per Hari</h2>
<table><tr><th>Tanggal</th><th class="r">Transaksi</th><th class="r">Pendapatan</th></tr>
@forelse($daily as $date => $row)
<tr><td>{{ \Carbon\Carbon::parse($date)->format('d/m/Y') }}</td><td class="r">{{ $row['count'] }}</td><td class="r">@rp($row['total'])</td></tr>
@empty<tr><td colspan="3">Tidak ada transaksi.</td></tr>@endforelse
</table>

<h2>Produk Terlaris</h2>
<table><tr><th>Produk</th><th class="r">Qty</th><th class="r">Pendapatan</th></tr>
@forelse($topProducts as $t)<tr><td>{{ $t->product_name }}</td><td class="r">{{ $t->qty }}</td><td class="r">@rp($t->revenue)</td></tr>
@empty<tr><td colspan="3">Tidak ada data.</td></tr>@endforelse
</table>

<h2>Daftar Transaksi</h2>
<table><tr><th>Invoice</th><th>Waktu</th><th>Pelanggan</th><th>Kasir</th><th>Bayar</th><th class="r">Total</th></tr>
@forelse($sales as $s)
<tr><td>{{ $s->invoice_no }}</td><td>{{ $s->sold_at->format('d/m/Y H:i') }}</td><td>{{ $s->customer->name ?? 'Umum' }}</td><td>{{ $s->user->name }}</td><td>{{ $s->method_label }}</td><td class="r">@rp($s->total)</td></tr>
@empty<tr><td colspan="6">Tidak ada transaksi.</td></tr>@endforelse
</table>
</body></html>
