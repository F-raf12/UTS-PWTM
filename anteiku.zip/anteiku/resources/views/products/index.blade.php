@extends('layouts.app')
@section('title', 'Produk')
@section('heading', 'Produk')
@section('content')
@php($admin = auth()->user()->isAdmin())
<div class="card">
    <div class="filter-bar">
        <form class="row g-2 align-items-center auto-submit" method="GET">
            <div class="col-xl-3 col-md-6"><div class="input-group"><span class="input-group-text"><i class="bi bi-search"></i></span>
                <input type="search" name="q" value="{{ request('q') }}" class="form-control" placeholder="Cari produk..."></div></div>
            <div class="col-xl-2 col-md-3 col-6"><select name="category" class="form-select">
                <option value="">Semua kategori</option>
                @foreach($categories as $c)<option value="{{ $c->id }}" @selected(request('category') == $c->id)>{{ $c->name }}</option>@endforeach
            </select></div>
            <div class="col-xl-2 col-md-3 col-6"><select name="stock" class="form-select">
                <option value="">Semua stok</option>
                <option value="low" @selected(request('stock') == 'low')>Stok menipis</option>
                <option value="empty" @selected(request('stock') == 'empty')>Stok habis</option>
            </select></div>
            <div class="col-xl-2 col-md-3 col-6"><select name="status" class="form-select">
                <option value="">Semua status</option>
                <option value="active" @selected(request('status') == 'active')>Aktif</option>
                <option value="inactive" @selected(request('status') == 'inactive')>Nonaktif</option>
            </select></div>
            <div class="col-auto"><button class="btn btn-soft">Cari</button>
                @if(request()->hasAny(['q','category','stock','status','sort']))<a href="{{ route('products.index') }}" class="btn btn-link">Reset</a>@endif</div>
            @if($admin)<div class="col-12 col-xl ms-xl-auto text-xl-end"><a href="{{ route('products.create') }}" class="btn btn-primary text-nowrap"><i class="bi bi-plus-lg"></i> Tambah Produk</a></div>@endif
        </form>
    </div>
    <div class="table-responsive">
        <table class="table">
            <thead><tr>
                <th>Gambar</th>
                <th><x-sort col="name" :sort="$sort" :dir="$dir">Produk</x-sort></th>
                <th>Kategori</th>
                <th><x-sort col="price" :sort="$sort" :dir="$dir">Harga</x-sort></th>
                <th><x-sort col="stock" :sort="$sort" :dir="$dir">Stok</x-sort></th>
                <th>Status</th>
                @if($admin)<th class="text-end">Aksi</th>@endif
            </tr></thead>
            <tbody>
            @forelse($products as $p)
                <tr>
                    <td>@if($p->image_url)<img src="{{ $p->image_url }}" class="thumb" alt="{{ $p->name }}">@else<div class="thumb-ph"><i class="bi bi-cup-hot"></i></div>@endif</td>
                    <td><div class="fw-medium">{{ $p->name }}</div><small class="text-muted">{{ \Illuminate\Support\Str::limit($p->description, 40) }}</small></td>
                    <td><span class="badge-soft badge-brown">{{ $p->category->name }}</span></td>
                    <td class="fw-medium">@rp($p->price)</td>
                    <td><span class="badge-soft {{ $p->stock == 0 ? 'badge-bad' : ($p->is_low_stock ? 'badge-warn' : 'badge-ok') }}">{{ $p->stock }}</span></td>
                    <td>{!! $p->is_active ? '<span class="badge-soft badge-ok">Aktif</span>' : '<span class="badge-soft badge-bad">Nonaktif</span>' !!}</td>
                    @if($admin)
                    <td class="text-end text-nowrap">
                        <a href="{{ route('products.edit', $p) }}" class="btn btn-sm btn-soft" title="Ubah"><i class="bi bi-pencil"></i></a>
                        <x-confirm-delete :action="route('products.destroy', $p)" message="Hapus produk {{ $p->name }}?" />
                    </td>
                    @endif
                </tr>
            @empty
                <tr><td colspan="7" class="empty"><i class="bi bi-cup-straw"></i>Produk tidak ditemukan.</td></tr>
            @endforelse
            </tbody>
        </table>
    </div>
    @if($products->hasPages())<div class="card-footer bg-transparent d-flex justify-content-between align-items-center flex-wrap gap-2">
        <small class="text-muted">Menampilkan {{ $products->firstItem() }}-{{ $products->lastItem() }} dari {{ $products->total() }}</small>{{ $products->links() }}</div>@endif
</div>
@endsection
