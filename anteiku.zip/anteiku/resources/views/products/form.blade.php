@extends('layouts.app')
@php($edit = $product->exists)
@section('title', $edit ? 'Ubah Produk' : 'Tambah Produk')
@section('heading', $edit ? 'Ubah Produk' : 'Tambah Produk')
@section('content')
<div class="card" style="max-width:820px"><div class="card-body p-4">
    <form method="POST" enctype="multipart/form-data" novalidate
          action="{{ $edit ? route('products.update', $product) : route('products.store') }}">
        @csrf @if($edit) @method('PUT') @endif
        <div class="row g-3">
            <div class="col-md-8">
                <label class="form-label" for="name">Nama Produk <span class="text-danger">*</span></label>
                <input id="name" name="name" value="{{ old('name', $product->name) }}" class="form-control @error('name') is-invalid @enderror" maxlength="120" required>
                @error('name')<div class="invalid-feedback">{{ $message }}</div>@enderror
            </div>
            <div class="col-md-4">
                <label class="form-label" for="category_id">Kategori <span class="text-danger">*</span></label>
                <select id="category_id" name="category_id" class="form-select @error('category_id') is-invalid @enderror" required>
                    <option value="">Pilih...</option>
                    @foreach($categories as $c)<option value="{{ $c->id }}" @selected(old('category_id', $product->category_id) == $c->id)>{{ $c->name }}</option>@endforeach
                </select>
                @error('category_id')<div class="invalid-feedback">{{ $message }}</div>@enderror
            </div>
            <div class="col-md-6">
                <label class="form-label" for="price">Harga (Rp) <span class="text-danger">*</span></label>
                <input id="price" type="number" min="0" name="price" value="{{ old('price', $product->price) }}" class="form-control @error('price') is-invalid @enderror" required>
                @error('price')<div class="invalid-feedback">{{ $message }}</div>@enderror
            </div>
            <div class="col-md-6">
                <label class="form-label" for="stock">Stok <span class="text-danger">*</span></label>
                <input id="stock" type="number" min="0" name="stock" value="{{ old('stock', $product->stock) }}" class="form-control @error('stock') is-invalid @enderror" required>
                @error('stock')<div class="invalid-feedback">{{ $message }}</div>@enderror
            </div>
            <div class="col-12">
                <label class="form-label" for="description">Deskripsi</label>
                <textarea id="description" name="description" rows="2" class="form-control @error('description') is-invalid @enderror" maxlength="500">{{ old('description', $product->description) }}</textarea>
                @error('description')<div class="invalid-feedback">{{ $message }}</div>@enderror
            </div>
            <div class="col-12">
                <label class="form-label" for="image">Gambar Produk</label>
                <div class="d-flex gap-3 align-items-center">
                    <img id="preview" src="{{ $product->image_url }}" class="thumb {{ $product->image_url ? '' : 'd-none' }}" style="width:84px;height:84px" alt="">
                    <div class="flex-grow-1">
                        <input id="image" type="file" name="image" accept="image/png,image/jpeg,image/webp" data-preview="#preview" class="form-control @error('image') is-invalid @enderror">
                        <small class="text-muted">JPG / PNG / WEBP, maksimal 2 MB.</small>
                        @error('image')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        @if($product->image)<div class="form-check mt-1"><input class="form-check-input" type="checkbox" name="remove_image" value="1" id="rm"><label class="form-check-label" for="rm">Hapus gambar saat ini</label></div>@endif
                    </div>
                </div>
            </div>
            <div class="col-12">
                <div class="form-check form-switch">
                    <input class="form-check-input" type="checkbox" role="switch" name="is_active" value="1" id="is_active" @checked(old('is_active', $product->is_active))>
                    <label class="form-check-label" for="is_active">Produk aktif (tampil di halaman transaksi)</label>
                </div>
            </div>
        </div>
        <div class="mt-4">
            <button class="btn btn-primary"><i class="bi bi-check-lg"></i> Simpan</button>
            <a href="{{ route('products.index') }}" class="btn btn-link">Batal</a>
        </div>
    </form>
</div></div>
@endsection
