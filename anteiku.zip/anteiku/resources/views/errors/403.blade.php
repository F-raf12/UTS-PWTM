@extends(auth()->check() ? 'layouts.app' : 'layouts.plain')
@section('title', 'Akses Ditolak')
@section('heading', 'Akses Ditolak')
@section('content')
<div class="card"><div class="empty">
    <i class="bi bi-shield-lock"></i>
    <h3 class="serif mt-2">403</h3>
    <p>{{ $exception->getMessage() ?: 'Anda tidak memiliki hak akses untuk halaman ini.' }}</p>
    <a href="{{ route('dashboard') }}" class="btn btn-primary">Kembali ke Dashboard</a>
</div></div>
@endsection
