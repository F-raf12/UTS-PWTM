@extends(auth()->check() ? 'layouts.app' : 'layouts.plain')
@section('title', 'Tidak Ditemukan')
@section('heading', 'Halaman Tidak Ditemukan')
@section('content')
<div class="card"><div class="empty">
    <i class="bi bi-cup"></i>
    <h3 class="serif mt-2">404</h3>
    <p>Halaman yang Anda cari tidak ada.</p>
    <a href="{{ route('dashboard') }}" class="btn btn-primary">Kembali ke Dashboard</a>
</div></div>
@endsection
