@extends('layouts.app')
@section('title', 'Riwayat Transaksi')
@section('heading', 'Riwayat Transaksi')
@section('content')
@php($admin = auth()->user()->isAdmin())
<div class="card">
    <div class="filter-bar">
        <form class="row g-2 align-items-end" method="GET">
            <div class="col-lg-3 col-md-6"><label class="form-label small mb-1">Cari</label>
                <input type="search" name="q" value="{{ request('q') }}" class="form-control" placeholder="No. invoice / pelanggan"></div>
            <div class="col-lg-2 col-6"><label class="form-label small mb-1">Dari tanggal</label>
                <input type="date" name="from" value="{{ request('from') }}" class="form-control @error('from') is-invalid @enderror"></div>
            <div class="col-lg-2 col-6"><label class="form-label small mb-1">Sampai</label>
                <input type="date" name="to" value="{{ request('to') }}" class="form-control @error('to') is-invalid @enderror"></div>
            <div class="col-lg-2 col-6"><label class="form-label small mb-1">Pembayaran</label>
                <select name="payment" class="form-select"><option value="">Semua</option>
                @foreach(\App\Models\Sale::METHODS as $k => $v)<option value="{{ $k }}" @selected(request('payment') == $k)>{{ $v }}</option>@endforeach</select></div>
            <div class="col-lg-2 col-6"><label class="form-label small mb-1">Status</label>
                <select name="status" class="form-select"><option value="">Semua</option>
                <option value="completed" @selected(request('status') == 'completed')>Selesai</option>
                <option value="cancelled" @selected(request('status') == 'cancelled')>Dibatalkan</option></select></div>
            @if($admin)<div class="col-lg-2 col-6"><label class="form-label small mb-1">Kasir</label>
                <select name="cashier" class="form-select"><option value="">Semua</option>
                @foreach($cashiers as $c)<option value="{{ $c->id }}" @selected(request('cashier') == $c->id)>{{ $c->name }}</option>@endforeach</select></div>@endif
            <div class="col-auto"><button class="btn btn-soft"><i class="bi bi-funnel"></i> Terapkan</button>
                @if(request()->hasAny(['q','from','to','payment','status','cashier','sort']))<a href="{{ route('sales.index') }}" class="btn btn-link">Reset</a>@endif</div>
        </form>
    </div>
    <div class="table-responsive">
        <table class="table">
            <thead><tr>
                <th><x-sort col="invoice_no" :sort="$sort" :dir="$dir">Invoice</x-sort></th>
                <th><x-sort col="sold_at" :sort="$sort" :dir="$dir">Waktu</x-sort></th>
                <th>Pelanggan</th>@if($admin)<th>Kasir</th>@endif
                <th>Item</th><th>Pembayaran</th>
                <th><x-sort col="total" :sort="$sort" :dir="$dir">Total</x-sort></th>
                <th>Status</th><th class="text-end">Aksi</th>
            </tr></thead>
            <tbody>
            @forelse($sales as $s)
                <tr>
                    <td class="fw-medium">{{ $s->invoice_no }}</td>
                    <td class="text-muted text-nowrap">{{ $s->sold_at->translatedFormat('d M Y, H:i') }}</td>
                    <td>{{ $s->customer->name ?? 'Umum' }}</td>
                    @if($admin)<td>{{ $s->user->name }}</td>@endif
                    <td>{{ (int) $s->items_count }}</td>
                    <td><span class="badge-soft badge-brown">{{ $s->method_label }}</span></td>
                    <td class="fw-semibold">@rp($s->total)</td>
                    <td>{!! $s->status === 'completed' ? '<span class="badge-soft badge-ok">Selesai</span>' : '<span class="badge-soft badge-bad">Dibatalkan</span>' !!}</td>
                    <td class="text-end"><a href="{{ route('sales.show', $s) }}" class="btn btn-sm btn-soft" title="Detail"><i class="bi bi-eye"></i></a></td>
                </tr>
            @empty
                <tr><td colspan="9" class="empty"><i class="bi bi-receipt"></i>Belum ada transaksi yang sesuai.</td></tr>
            @endforelse
            </tbody>
        </table>
    </div>
    @if($sales->hasPages())<div class="card-footer bg-transparent d-flex justify-content-between align-items-center flex-wrap gap-2">
        <small class="text-muted">Menampilkan {{ $sales->firstItem() }}-{{ $sales->lastItem() }} dari {{ $sales->total() }}</small>{{ $sales->links() }}</div>@endif
</div>
@endsection
