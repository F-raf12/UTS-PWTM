@extends('layouts.app')
@section('title', $sale->invoice_no)
@section('heading', 'Detail Transaksi')
@section('content')
<div class="d-flex flex-wrap gap-2 mb-3 no-print">
    <a href="{{ route('sales.index') }}" class="btn btn-soft"><i class="bi bi-arrow-left"></i> Riwayat</a>
    <a href="{{ route('sales.create') }}" class="btn btn-primary"><i class="bi bi-plus-lg"></i> Transaksi Baru</a>
    <button class="btn btn-soft" onclick="window.print()"><i class="bi bi-printer"></i> Cetak Struk</button>
    @if(auth()->user()->isAdmin() && $sale->status === 'completed')
        <form method="POST" action="{{ route('sales.cancel', $sale) }}" data-confirm="Batalkan transaksi ini? Stok produk akan dikembalikan.">@csrf
            <button class="btn btn-outline-danger"><i class="bi bi-x-circle"></i> Batalkan Transaksi</button></form>
    @endif
</div>

<div class="card"><div class="card-body p-4">
    <div class="receipt">
        <div class="text-center">
            <h4 class="serif mb-0">Anteiku</h4><div>Coffee &amp; Dessert Shop</div><hr>
        </div>
        <div class="d-flex justify-content-between"><span>No</span><span>{{ $sale->invoice_no }}</span></div>
        <div class="d-flex justify-content-between"><span>Tanggal</span><span>{{ $sale->sold_at->format('d/m/Y H:i') }}</span></div>
        <div class="d-flex justify-content-between"><span>Kasir</span><span>{{ $sale->user->name }}</span></div>
        <div class="d-flex justify-content-between"><span>Pelanggan</span><span>{{ $sale->customer->name ?? 'Umum' }}</span></div>
        @if($sale->status === 'cancelled')<div class="text-center fw-bold text-danger my-2">*** DIBATALKAN ***</div>@endif
        <hr>
        @foreach($sale->details as $d)
            <div>{{ $d->product_name }}</div>
            <div class="d-flex justify-content-between"><span>&nbsp;&nbsp;{{ $d->qty }} x {{ number_format($d->price, 0, ',', '.') }}</span><span>{{ number_format($d->subtotal, 0, ',', '.') }}</span></div>
        @endforeach
        <hr>
        <div class="d-flex justify-content-between fw-bold"><span>TOTAL</span><span>@rp($sale->total)</span></div>
        <div class="d-flex justify-content-between"><span>Bayar ({{ $sale->method_label }})</span><span>@rp($sale->paid)</span></div>
        <div class="d-flex justify-content-between"><span>Kembali</span><span>@rp($sale->change_amount)</span></div>
        @if($sale->notes)<hr><div>Catatan: {{ $sale->notes }}</div>@endif
        <hr><div class="text-center">Terima kasih, sampai jumpa lagi!</div>
    </div>
</div></div>
@endsection
