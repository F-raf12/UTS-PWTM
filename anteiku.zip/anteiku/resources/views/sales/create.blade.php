@extends('layouts.app')
@section('title', 'Transaksi Baru')
@section('heading', 'Transaksi Baru')
@section('content')
@if($errors->any())
    <div class="alert alert-danger border-0 shadow-sm"><i class="bi bi-exclamation-triangle-fill me-1"></i> {{ $errors->first() }}</div>
@endif

<form method="POST" action="{{ route('sales.store') }}" id="posForm" novalidate>
@csrf
<div class="pos-grid">
    {{-- ===== Daftar menu ===== --}}
    <div>
        <div class="card mb-3"><div class="card-body d-flex flex-wrap gap-3 align-items-center">
            <div class="input-group" style="max-width:300px"><span class="input-group-text"><i class="bi bi-search"></i></span>
                <input type="search" id="menuSearch" class="form-control" placeholder="Cari menu..."></div>
            <div class="cat-pills" id="catPills">
                <button type="button" class="pill active" data-cat="">Semua</button>
                @foreach($categories as $c)<button type="button" class="pill" data-cat="{{ $c->id }}">{{ $c->name }}</button>@endforeach
            </div>
        </div></div>

        <div class="menu-grid" id="menuGrid">
            @foreach($products as $p)
                <button type="button" class="menu-item {{ $p->stock < 1 ? 'disabled' : '' }}" data-id="{{ $p->id }}"
                        data-name="{{ strtolower($p->name) }}" data-cat="{{ $p->category_id }}" {{ $p->stock < 1 ? 'disabled' : '' }}>
                    <div class="menu-img">@if($p->image_url)<img src="{{ $p->image_url }}" alt="{{ $p->name }}">@else<i class="bi bi-cup-hot"></i>@endif</div>
                    <div class="menu-body">
                        <div class="menu-name">{{ $p->name }}</div>
                        <div class="menu-price">@rp($p->price)</div>
                        <div class="menu-stock">{{ $p->stock < 1 ? 'Stok habis' : 'Stok: ' . $p->stock }}</div>
                    </div>
                </button>
            @endforeach
        </div>
        <div class="empty d-none" id="noMenu"><i class="bi bi-search"></i>Menu tidak ditemukan.</div>
    </div>

    {{-- ===== Keranjang ===== --}}
    <div class="cart"><div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <span><i class="bi bi-bag"></i> Pesanan</span>
            <button type="button" class="btn btn-sm btn-link text-danger p-0" id="clearCart">Kosongkan</button>
        </div>
        <div class="card-body">
            <div id="cartLines" style="max-height:300px;overflow:auto"></div>
            <div class="empty py-4" id="cartEmpty"><i class="bi bi-basket"></i>Belum ada item. Klik menu untuk menambahkan.</div>
            <div id="cartInputs"></div>

            <div class="total-box mt-3">
                <div class="d-flex justify-content-between"><span class="text-muted">Jumlah item</span><span id="itemCount">0</span></div>
                <div class="d-flex justify-content-between align-items-center"><span class="fw-medium">Total</span><span class="grand" id="grandTotal">Rp 0</span></div>
            </div>

            <div class="mt-3">
                <label class="form-label" for="customer_id">Pelanggan</label>
                <select name="customer_id" id="customer_id" class="form-select">
                    <option value="">Pelanggan umum</option>
                    @foreach($customers as $c)<option value="{{ $c->id }}" @selected(old('customer_id') == $c->id)>{{ $c->name }}{{ $c->phone ? ' - ' . $c->phone : '' }}</option>@endforeach
                </select>
            </div>
            <div class="mt-3">
                <label class="form-label" for="payment_method">Metode Pembayaran</label>
                <select name="payment_method" id="payment_method" class="form-select">
                    @foreach(\App\Models\Sale::METHODS as $k => $v)<option value="{{ $k }}" @selected(old('payment_method', 'tunai') == $k)>{{ $v }}</option>@endforeach
                </select>
            </div>
            <div class="mt-3" id="cashBox">
                <label class="form-label" for="paid">Uang Diterima (Rp)</label>
                <input type="number" min="0" name="paid" id="paid" value="{{ old('paid') }}" class="form-control @error('paid') is-invalid @enderror">
                @error('paid')<div class="invalid-feedback">{{ $message }}</div>@enderror
                <div class="d-flex flex-wrap gap-1 mt-2" id="quickCash"></div>
                <div class="d-flex justify-content-between mt-2"><span class="text-muted">Kembalian</span><strong id="changeAmt">Rp 0</strong></div>
            </div>
            <div class="mt-3">
                <input type="text" name="notes" value="{{ old('notes') }}" maxlength="255" class="form-control" placeholder="Catatan (opsional)">
            </div>
            <button class="btn btn-primary w-100 mt-3 py-2" type="submit" id="submitBtn" disabled><i class="bi bi-check2-circle"></i> Simpan Transaksi</button>
        </div>
    </div></div>
</div>
</form>
@endsection

@push('scripts')
@php
    $jsProducts = $products->mapWithKeys(fn ($p) => [$p->id => ['id' => $p->id, 'name' => $p->name, 'price' => $p->price, 'stock' => $p->stock]]);
    $jsOld = old('items', []);
@endphp
<script>
(() => {
  const products = @json($jsProducts);
  const cart = {};   // product_id -> qty
  const rp = n => 'Rp ' + Number(n).toLocaleString('id-ID');
  const $ = s => document.querySelector(s);

  // Pulihkan keranjang jika validasi server gagal
  (@json($jsOld)).forEach(i => { if (products[i.product_id]) cart[i.product_id] = Math.min(+i.qty || 1, products[i.product_id].stock); });

  function total() { return Object.entries(cart).reduce((s, [id, q]) => s + products[id].price * q, 0); }

  function render() {
    const ids = Object.keys(cart);
    $('#cartEmpty').classList.toggle('d-none', ids.length > 0);
    $('#cartLines').innerHTML = ids.map(id => {
      const p = products[id], q = cart[id];
      return `<div class="cart-line">
        <div class="flex-grow-1"><div class="fw-medium">${p.name}</div><small class="text-muted">${rp(p.price)} x ${q}</small></div>
        <div class="qty"><button type="button" data-act="dec" data-id="${id}">−</button><span>${q}</span><button type="button" data-act="inc" data-id="${id}">+</button></div>
        <div class="fw-semibold text-end" style="min-width:84px">${rp(p.price * q)}</div>
        <button type="button" class="btn btn-sm text-danger p-0" data-act="del" data-id="${id}"><i class="bi bi-x-lg"></i></button>
      </div>`;
    }).join('');
    $('#cartInputs').innerHTML = ids.map((id, i) =>
      `<input type="hidden" name="items[${i}][product_id]" value="${id}"><input type="hidden" name="items[${i}][qty]" value="${cart[id]}">`).join('');
    $('#itemCount').textContent = Object.values(cart).reduce((a, b) => a + b, 0);
    $('#grandTotal').textContent = rp(total());
    updatePayment();
  }

  function updatePayment() {
    const t = total(), cash = $('#payment_method').value === 'tunai';
    $('#cashBox').classList.toggle('d-none', !cash);
    const paid = +$('#paid').value || 0;
    $('#changeAmt').textContent = rp(Math.max(0, paid - t));
    $('#changeAmt').style.color = paid >= t ? '' : 'var(--bad)';
    $('#submitBtn').disabled = t === 0 || (cash && paid < t);
    const quick = [t, ...[20000, 50000, 100000, 200000].filter(v => v > t)].filter(v => v > 0).slice(0, 4);
    $('#quickCash').innerHTML = quick.map((v, i) => `<button type="button" class="btn btn-sm btn-soft" data-cash="${v}">${i === 0 ? 'Uang pas' : rp(v)}</button>`).join('');
  }

  function add(id) {
    const p = products[id]; if (!p) return;
    if ((cart[id] || 0) >= p.stock) { alert('Stok ' + p.name + ' hanya tersisa ' + p.stock); return; }
    cart[id] = (cart[id] || 0) + 1; render();
  }

  $('#menuGrid').addEventListener('click', e => { const b = e.target.closest('.menu-item'); if (b && !b.disabled) add(b.dataset.id); });
  $('#cartLines').addEventListener('click', e => {
    const b = e.target.closest('[data-act]'); if (!b) return;
    const id = b.dataset.id;
    if (b.dataset.act === 'inc') add(id);
    if (b.dataset.act === 'dec') { cart[id]--; if (cart[id] < 1) delete cart[id]; render(); }
    if (b.dataset.act === 'del') { delete cart[id]; render(); }
  });
  $('#clearCart').addEventListener('click', () => { Object.keys(cart).forEach(k => delete cart[k]); render(); });
  $('#quickCash').addEventListener('click', e => { const b = e.target.closest('[data-cash]'); if (b) { $('#paid').value = b.dataset.cash; updatePayment(); } });
  $('#paid').addEventListener('input', updatePayment);
  $('#payment_method').addEventListener('change', updatePayment);

  // Pencarian & filter kategori menu
  let cat = '';
  function filterMenu() {
    const q = $('#menuSearch').value.trim().toLowerCase(); let shown = 0;
    document.querySelectorAll('.menu-item').forEach(el => {
      const ok = (!cat || el.dataset.cat === cat) && el.dataset.name.includes(q);
      el.classList.toggle('d-none', !ok); if (ok) shown++;
    });
    $('#noMenu').classList.toggle('d-none', shown > 0);
  }
  $('#menuSearch').addEventListener('input', filterMenu);
  $('#catPills').addEventListener('click', e => {
    const b = e.target.closest('.pill'); if (!b) return;
    document.querySelectorAll('#catPills .pill').forEach(x => x.classList.remove('active'));
    b.classList.add('active'); cat = b.dataset.cat; filterMenu();
  });

  render();
})();
</script>
@endpush
