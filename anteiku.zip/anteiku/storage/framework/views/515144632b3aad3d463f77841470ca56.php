<?php $__env->startSection('title', 'Manajemen User'); ?>
<?php $__env->startSection('heading', 'Manajemen User'); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="filter-bar">
        <form class="row g-2 align-items-center auto-submit" method="GET">
            <div class="col-lg-4 col-md-6"><div class="input-group"><span class="input-group-text"><i class="bi bi-search"></i></span>
                <input type="search" name="q" value="<?php echo e(request('q')); ?>" class="form-control" placeholder="Cari nama atau email..."></div></div>
            <div class="col-lg-2 col-6"><select name="role" class="form-select">
                <option value="">Semua role</option><option value="admin" <?php if(request('role') == 'admin'): echo 'selected'; endif; ?>>Admin</option><option value="kasir" <?php if(request('role') == 'kasir'): echo 'selected'; endif; ?>>Kasir</option>
            </select></div>
            <div class="col-lg-2 col-6"><select name="status" class="form-select">
                <option value="">Semua status</option><option value="active" <?php if(request('status') == 'active'): echo 'selected'; endif; ?>>Aktif</option><option value="inactive" <?php if(request('status') == 'inactive'): echo 'selected'; endif; ?>>Nonaktif</option>
            </select></div>
            <div class="col-auto"><button class="btn btn-soft">Cari</button>
                <?php if(request()->hasAny(['q','role','status','sort'])): ?><a href="<?php echo e(route('users.index')); ?>" class="btn btn-link">Reset</a><?php endif; ?></div>
            <div class="col text-lg-end"><a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary"><i class="bi bi-person-plus"></i> Tambah User</a></div>
        </form>
    </div>
    <div class="table-responsive">
        <table class="table">
            <thead><tr>
                <th><?php if (isset($component)) { $__componentOriginal6a44cb87e86b7d587c0ef29d28e1a20e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6a44cb87e86b7d587c0ef29d28e1a20e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sort','data' => ['col' => 'name','sort' => $sort,'dir' => $dir]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sort'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['col' => 'name','sort' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sort),'dir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($dir)]); ?>Nama <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6a44cb87e86b7d587c0ef29d28e1a20e)): ?>
<?php $attributes = $__attributesOriginal6a44cb87e86b7d587c0ef29d28e1a20e; ?>
<?php unset($__attributesOriginal6a44cb87e86b7d587c0ef29d28e1a20e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6a44cb87e86b7d587c0ef29d28e1a20e)): ?>
<?php $component = $__componentOriginal6a44cb87e86b7d587c0ef29d28e1a20e; ?>
<?php unset($__componentOriginal6a44cb87e86b7d587c0ef29d28e1a20e); ?>
<?php endif; ?></th>
                <th><?php if (isset($component)) { $__componentOriginal6a44cb87e86b7d587c0ef29d28e1a20e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6a44cb87e86b7d587c0ef29d28e1a20e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sort','data' => ['col' => 'email','sort' => $sort,'dir' => $dir]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sort'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['col' => 'email','sort' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sort),'dir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($dir)]); ?>Email <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6a44cb87e86b7d587c0ef29d28e1a20e)): ?>
<?php $attributes = $__attributesOriginal6a44cb87e86b7d587c0ef29d28e1a20e; ?>
<?php unset($__attributesOriginal6a44cb87e86b7d587c0ef29d28e1a20e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6a44cb87e86b7d587c0ef29d28e1a20e)): ?>
<?php $component = $__componentOriginal6a44cb87e86b7d587c0ef29d28e1a20e; ?>
<?php unset($__componentOriginal6a44cb87e86b7d587c0ef29d28e1a20e); ?>
<?php endif; ?></th>
                <th><?php if (isset($component)) { $__componentOriginal6a44cb87e86b7d587c0ef29d28e1a20e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6a44cb87e86b7d587c0ef29d28e1a20e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sort','data' => ['col' => 'role','sort' => $sort,'dir' => $dir]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sort'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['col' => 'role','sort' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sort),'dir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($dir)]); ?>Role <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6a44cb87e86b7d587c0ef29d28e1a20e)): ?>
<?php $attributes = $__attributesOriginal6a44cb87e86b7d587c0ef29d28e1a20e; ?>
<?php unset($__attributesOriginal6a44cb87e86b7d587c0ef29d28e1a20e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6a44cb87e86b7d587c0ef29d28e1a20e)): ?>
<?php $component = $__componentOriginal6a44cb87e86b7d587c0ef29d28e1a20e; ?>
<?php unset($__componentOriginal6a44cb87e86b7d587c0ef29d28e1a20e); ?>
<?php endif; ?></th>
                <th>Status</th><th>Transaksi</th>
                <th class="text-end">Aksi</th>
            </tr></thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><div class="d-flex align-items-center gap-2"><div class="avatar" style="width:34px;height:34px"><?php echo e($u->initials); ?></div>
                        <span class="fw-medium"><?php echo e($u->name); ?></span><?php if($u->is(auth()->user())): ?><span class="badge-soft badge-brown">Anda</span><?php endif; ?></div></td>
                    <td><?php echo e($u->email); ?></td>
                    <td><span class="badge-soft <?php echo e($u->isAdmin() ? 'badge-warn' : 'badge-brown'); ?>"><?php echo e($u->role_label); ?></span></td>
                    <td><?php echo $u->is_active ? '<span class="badge-soft badge-ok">Aktif</span>' : '<span class="badge-soft badge-bad">Nonaktif</span>'; ?></td>
                    <td><?php echo e($u->sales_count); ?></td>
                    <td class="text-end text-nowrap">
                        <a href="<?php echo e(route('users.edit', $u)); ?>" class="btn btn-sm btn-soft" title="Ubah"><i class="bi bi-pencil"></i></a>
                        <?php if (! ($u->is(auth()->user()))): ?><?php if (isset($component)) { $__componentOriginal31d8dad53715b0a3883f430a1e78226c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal31d8dad53715b0a3883f430a1e78226c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.confirm-delete','data' => ['action' => route('users.destroy', $u),'message' => 'Hapus akun '.e($u->name).'?']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('confirm-delete'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['action' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('users.destroy', $u)),'message' => 'Hapus akun '.e($u->name).'?']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal31d8dad53715b0a3883f430a1e78226c)): ?>
<?php $attributes = $__attributesOriginal31d8dad53715b0a3883f430a1e78226c; ?>
<?php unset($__attributesOriginal31d8dad53715b0a3883f430a1e78226c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal31d8dad53715b0a3883f430a1e78226c)): ?>
<?php $component = $__componentOriginal31d8dad53715b0a3883f430a1e78226c; ?>
<?php unset($__componentOriginal31d8dad53715b0a3883f430a1e78226c); ?>
<?php endif; ?><?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="6" class="empty"><i class="bi bi-person-x"></i>User tidak ditemukan.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if($users->hasPages()): ?><div class="card-footer bg-transparent d-flex justify-content-between align-items-center flex-wrap gap-2">
        <small class="text-muted">Menampilkan <?php echo e($users->firstItem()); ?>-<?php echo e($users->lastItem()); ?> dari <?php echo e($users->total()); ?></small><?php echo e($users->links()); ?></div><?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel12-app\anteiku\anteiku\resources\views/users/index.blade.php ENDPATH**/ ?>