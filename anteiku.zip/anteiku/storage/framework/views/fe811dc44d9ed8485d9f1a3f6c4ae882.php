<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['col', 'sort', 'dir']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['col', 'sort', 'dir']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php
    $active = $sort === $col;
    $next = $active && $dir === 'asc' ? 'desc' : 'asc';
?>
<a href="<?php echo e(request()->fullUrlWithQuery(['sort' => $col, 'dir' => $next, 'page' => null])); ?>">
    <?php echo e($slot); ?>

    <i class="bi <?php echo e($active ? ($dir === 'asc' ? 'bi-sort-up' : 'bi-sort-down') : 'bi-arrow-down-up opacity-25'); ?>"></i>
</a>
<?php /**PATH C:\xampp\htdocs\laravel12-app\anteiku\anteiku\resources\views/components/sort.blade.php ENDPATH**/ ?>