<?php $__env->startSection('title', $sale->invoice_no); ?>
<?php $__env->startSection('heading', 'Detail Transaksi'); ?>
<?php $__env->startSection('content'); ?>
<div class="d-flex flex-wrap gap-2 mb-3 no-print">
    <a href="<?php echo e(route('sales.index')); ?>" class="btn btn-soft"><i class="bi bi-arrow-left"></i> Riwayat</a>
    <a href="<?php echo e(route('sales.create')); ?>" class="btn btn-primary"><i class="bi bi-plus-lg"></i> Transaksi Baru</a>
    <button class="btn btn-soft" onclick="window.print()"><i class="bi bi-printer"></i> Cetak Struk</button>
    <?php if(auth()->user()->isAdmin() && $sale->status === 'completed'): ?>
        <form method="POST" action="<?php echo e(route('sales.cancel', $sale)); ?>" data-confirm="Batalkan transaksi ini? Stok produk akan dikembalikan."><?php echo csrf_field(); ?>
            <button class="btn btn-outline-danger"><i class="bi bi-x-circle"></i> Batalkan Transaksi</button></form>
    <?php endif; ?>
</div>

<div class="card"><div class="card-body p-4">
    <div class="receipt">
        <div class="text-center">
            <h4 class="serif mb-0">Anteiku</h4><div>Coffee &amp; Dessert Shop</div><hr>
        </div>
        <div class="d-flex justify-content-between"><span>No</span><span><?php echo e($sale->invoice_no); ?></span></div>
        <div class="d-flex justify-content-between"><span>Tanggal</span><span><?php echo e($sale->sold_at->format('d/m/Y H:i')); ?></span></div>
        <div class="d-flex justify-content-between"><span>Kasir</span><span><?php echo e($sale->user->name); ?></span></div>
        <div class="d-flex justify-content-between"><span>Pelanggan</span><span><?php echo e($sale->customer->name ?? 'Umum'); ?></span></div>
        <?php if($sale->status === 'cancelled'): ?><div class="text-center fw-bold text-danger my-2">*** DIBATALKAN ***</div><?php endif; ?>
        <hr>
        <?php $__currentLoopData = $sale->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div><?php echo e($d->product_name); ?></div>
            <div class="d-flex justify-content-between"><span>&nbsp;&nbsp;<?php echo e($d->qty); ?> x <?php echo e(number_format($d->price, 0, ',', '.')); ?></span><span><?php echo e(number_format($d->subtotal, 0, ',', '.')); ?></span></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <hr>
        <div class="d-flex justify-content-between fw-bold"><span>TOTAL</span><span><?php echo 'Rp ' . number_format((int) ($sale->total), 0, ',', '.'); ?></span></div>
        <div class="d-flex justify-content-between"><span>Bayar (<?php echo e($sale->method_label); ?>)</span><span><?php echo 'Rp ' . number_format((int) ($sale->paid), 0, ',', '.'); ?></span></div>
        <div class="d-flex justify-content-between"><span>Kembali</span><span><?php echo 'Rp ' . number_format((int) ($sale->change_amount), 0, ',', '.'); ?></span></div>
        <?php if($sale->notes): ?><hr><div>Catatan: <?php echo e($sale->notes); ?></div><?php endif; ?>
        <hr><div class="text-center">Terima kasih, sampai jumpa lagi!</div>
    </div>
</div></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel12-app\anteiku\anteiku\resources\views/sales/show.blade.php ENDPATH**/ ?>