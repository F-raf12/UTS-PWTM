<?php $__env->startSection('title', 'Kategori'); ?>
<?php $__env->startSection('heading', 'Kategori Produk'); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="filter-bar">
        <form class="row g-2 align-items-center" method="GET">
            <div class="col-md-5"><div class="input-group"><span class="input-group-text"><i class="bi bi-search"></i></span>
                <input type="search" name="q" value="<?php echo e(request('q')); ?>" class="form-control" placeholder="Cari kategori..."></div></div>
            <div class="col-auto"><button class="btn btn-soft">Cari</button>
                <?php if(request()->hasAny(['q','sort'])): ?><a href="<?php echo e(route('categories.index')); ?>" class="btn btn-link">Reset</a><?php endif; ?></div>
            <div class="col text-md-end"><a href="<?php echo e(route('categories.create')); ?>" class="btn btn-primary"><i class="bi bi-plus-lg"></i> Tambah Kategori</a></div>
        </form>
    </div>
    <div class="table-responsive">
        <table class="table">
            <thead><tr>
                <th>#</th>
                <th><?php if (isset($component)) { $__componentOriginal6a44cb87e86b7d587c0ef29d28e1a20e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6a44cb87e86b7d587c0ef29d28e1a20e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sort','data' => ['col' => 'name','sort' => $sort,'dir' => $dir]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sort'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['col' => 'name','sort' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sort),'dir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($dir)]); ?>Nama <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6a44cb87e86b7d587c0ef29d28e1a20e)): ?>
<?php $attributes = $__attributesOriginal6a44cb87e86b7d587c0ef29d28e1a20e; ?>
<?php unset($__attributesOriginal6a44cb87e86b7d587c0ef29d28e1a20e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6a44cb87e86b7d587c0ef29d28e1a20e)): ?>
<?php $component = $__componentOriginal6a44cb87e86b7d587c0ef29d28e1a20e; ?>
<?php unset($__componentOriginal6a44cb87e86b7d587c0ef29d28e1a20e); ?>
<?php endif; ?></th>
                <th>Deskripsi</th>
                <th><?php if (isset($component)) { $__componentOriginal6a44cb87e86b7d587c0ef29d28e1a20e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6a44cb87e86b7d587c0ef29d28e1a20e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sort','data' => ['col' => 'products_count','sort' => $sort,'dir' => $dir]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sort'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['col' => 'products_count','sort' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sort),'dir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($dir)]); ?>Jumlah Produk <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6a44cb87e86b7d587c0ef29d28e1a20e)): ?>
<?php $attributes = $__attributesOriginal6a44cb87e86b7d587c0ef29d28e1a20e; ?>
<?php unset($__attributesOriginal6a44cb87e86b7d587c0ef29d28e1a20e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6a44cb87e86b7d587c0ef29d28e1a20e)): ?>
<?php $component = $__componentOriginal6a44cb87e86b7d587c0ef29d28e1a20e; ?>
<?php unset($__componentOriginal6a44cb87e86b7d587c0ef29d28e1a20e); ?>
<?php endif; ?></th>
                <th class="text-end">Aksi</th>
            </tr></thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($categories->firstItem() + $loop->index); ?></td>
                    <td class="fw-medium"><?php echo e($c->name); ?></td>
                    <td class="text-muted"><?php echo e($c->description ?: '-'); ?></td>
                    <td><span class="badge-soft badge-brown"><?php echo e($c->products_count); ?> produk</span></td>
                    <td class="text-end text-nowrap">
                        <a href="<?php echo e(route('categories.edit', $c)); ?>" class="btn btn-sm btn-soft" title="Ubah"><i class="bi bi-pencil"></i></a>
                        <?php if (isset($component)) { $__componentOriginal31d8dad53715b0a3883f430a1e78226c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal31d8dad53715b0a3883f430a1e78226c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.confirm-delete','data' => ['action' => route('categories.destroy', $c),'message' => 'Hapus kategori '.e($c->name).'?']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('confirm-delete'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['action' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('categories.destroy', $c)),'message' => 'Hapus kategori '.e($c->name).'?']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal31d8dad53715b0a3883f430a1e78226c)): ?>
<?php $attributes = $__attributesOriginal31d8dad53715b0a3883f430a1e78226c; ?>
<?php unset($__attributesOriginal31d8dad53715b0a3883f430a1e78226c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal31d8dad53715b0a3883f430a1e78226c)): ?>
<?php $component = $__componentOriginal31d8dad53715b0a3883f430a1e78226c; ?>
<?php unset($__componentOriginal31d8dad53715b0a3883f430a1e78226c); ?>
<?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="5" class="empty"><i class="bi bi-tags"></i>Belum ada kategori.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if($categories->hasPages()): ?><div class="card-footer bg-transparent d-flex justify-content-between align-items-center">
        <small class="text-muted">Menampilkan <?php echo e($categories->firstItem()); ?>-<?php echo e($categories->lastItem()); ?> dari <?php echo e($categories->total()); ?></small><?php echo e($categories->links()); ?></div><?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel12-app\anteiku\anteiku\resources\views/categories/index.blade.php ENDPATH**/ ?>