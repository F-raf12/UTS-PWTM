<?php $__env->startSection('title', 'Riwayat Transaksi'); ?>
<?php $__env->startSection('heading', 'Riwayat Transaksi'); ?>
<?php $__env->startSection('content'); ?>
<?php ($admin = auth()->user()->isAdmin()); ?>
<div class="card">
    <div class="filter-bar">
        <form class="row g-2 align-items-end" method="GET">
            <div class="col-lg-3 col-md-6"><label class="form-label small mb-1">Cari</label>
                <input type="search" name="q" value="<?php echo e(request('q')); ?>" class="form-control" placeholder="No. invoice / pelanggan"></div>
            <div class="col-lg-2 col-6"><label class="form-label small mb-1">Dari tanggal</label>
                <input type="date" name="from" value="<?php echo e(request('from')); ?>" class="form-control <?php $__errorArgs = ['from'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"></div>
            <div class="col-lg-2 col-6"><label class="form-label small mb-1">Sampai</label>
                <input type="date" name="to" value="<?php echo e(request('to')); ?>" class="form-control <?php $__errorArgs = ['to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"></div>
            <div class="col-lg-2 col-6"><label class="form-label small mb-1">Pembayaran</label>
                <select name="payment" class="form-select"><option value="">Semua</option>
                <?php $__currentLoopData = \App\Models\Sale::METHODS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($k); ?>" <?php if(request('payment') == $k): echo 'selected'; endif; ?>><?php echo e($v); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
            <div class="col-lg-2 col-6"><label class="form-label small mb-1">Status</label>
                <select name="status" class="form-select"><option value="">Semua</option>
                <option value="completed" <?php if(request('status') == 'completed'): echo 'selected'; endif; ?>>Selesai</option>
                <option value="cancelled" <?php if(request('status') == 'cancelled'): echo 'selected'; endif; ?>>Dibatalkan</option></select></div>
            <?php if($admin): ?><div class="col-lg-2 col-6"><label class="form-label small mb-1">Kasir</label>
                <select name="cashier" class="form-select"><option value="">Semua</option>
                <?php $__currentLoopData = $cashiers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($c->id); ?>" <?php if(request('cashier') == $c->id): echo 'selected'; endif; ?>><?php echo e($c->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div><?php endif; ?>
            <div class="col-auto"><button class="btn btn-soft"><i class="bi bi-funnel"></i> Terapkan</button>
                <?php if(request()->hasAny(['q','from','to','payment','status','cashier','sort'])): ?><a href="<?php echo e(route('sales.index')); ?>" class="btn btn-link">Reset</a><?php endif; ?></div>
        </form>
    </div>
    <div class="table-responsive">
        <table class="table">
            <thead><tr>
                <th><?php if (isset($component)) { $__componentOriginal6a44cb87e86b7d587c0ef29d28e1a20e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6a44cb87e86b7d587c0ef29d28e1a20e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sort','data' => ['col' => 'invoice_no','sort' => $sort,'dir' => $dir]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sort'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['col' => 'invoice_no','sort' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sort),'dir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($dir)]); ?>Invoice <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6a44cb87e86b7d587c0ef29d28e1a20e)): ?>
<?php $attributes = $__attributesOriginal6a44cb87e86b7d587c0ef29d28e1a20e; ?>
<?php unset($__attributesOriginal6a44cb87e86b7d587c0ef29d28e1a20e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6a44cb87e86b7d587c0ef29d28e1a20e)): ?>
<?php $component = $__componentOriginal6a44cb87e86b7d587c0ef29d28e1a20e; ?>
<?php unset($__componentOriginal6a44cb87e86b7d587c0ef29d28e1a20e); ?>
<?php endif; ?></th>
                <th><?php if (isset($component)) { $__componentOriginal6a44cb87e86b7d587c0ef29d28e1a20e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6a44cb87e86b7d587c0ef29d28e1a20e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sort','data' => ['col' => 'sold_at','sort' => $sort,'dir' => $dir]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sort'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['col' => 'sold_at','sort' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sort),'dir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($dir)]); ?>Waktu <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6a44cb87e86b7d587c0ef29d28e1a20e)): ?>
<?php $attributes = $__attributesOriginal6a44cb87e86b7d587c0ef29d28e1a20e; ?>
<?php unset($__attributesOriginal6a44cb87e86b7d587c0ef29d28e1a20e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6a44cb87e86b7d587c0ef29d28e1a20e)): ?>
<?php $component = $__componentOriginal6a44cb87e86b7d587c0ef29d28e1a20e; ?>
<?php unset($__componentOriginal6a44cb87e86b7d587c0ef29d28e1a20e); ?>
<?php endif; ?></th>
                <th>Pelanggan</th><?php if($admin): ?><th>Kasir</th><?php endif; ?>
                <th>Item</th><th>Pembayaran</th>
                <th><?php if (isset($component)) { $__componentOriginal6a44cb87e86b7d587c0ef29d28e1a20e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6a44cb87e86b7d587c0ef29d28e1a20e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sort','data' => ['col' => 'total','sort' => $sort,'dir' => $dir]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sort'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['col' => 'total','sort' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sort),'dir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($dir)]); ?>Total <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6a44cb87e86b7d587c0ef29d28e1a20e)): ?>
<?php $attributes = $__attributesOriginal6a44cb87e86b7d587c0ef29d28e1a20e; ?>
<?php unset($__attributesOriginal6a44cb87e86b7d587c0ef29d28e1a20e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6a44cb87e86b7d587c0ef29d28e1a20e)): ?>
<?php $component = $__componentOriginal6a44cb87e86b7d587c0ef29d28e1a20e; ?>
<?php unset($__componentOriginal6a44cb87e86b7d587c0ef29d28e1a20e); ?>
<?php endif; ?></th>
                <th>Status</th><th class="text-end">Aksi</th>
            </tr></thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="fw-medium"><?php echo e($s->invoice_no); ?></td>
                    <td class="text-muted text-nowrap"><?php echo e($s->sold_at->translatedFormat('d M Y, H:i')); ?></td>
                    <td><?php echo e($s->customer->name ?? 'Umum'); ?></td>
                    <?php if($admin): ?><td><?php echo e($s->user->name); ?></td><?php endif; ?>
                    <td><?php echo e((int) $s->items_count); ?></td>
                    <td><span class="badge-soft badge-brown"><?php echo e($s->method_label); ?></span></td>
                    <td class="fw-semibold"><?php echo 'Rp ' . number_format((int) ($s->total), 0, ',', '.'); ?></td>
                    <td><?php echo $s->status === 'completed' ? '<span class="badge-soft badge-ok">Selesai</span>' : '<span class="badge-soft badge-bad">Dibatalkan</span>'; ?></td>
                    <td class="text-end"><a href="<?php echo e(route('sales.show', $s)); ?>" class="btn btn-sm btn-soft" title="Detail"><i class="bi bi-eye"></i></a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="9" class="empty"><i class="bi bi-receipt"></i>Belum ada transaksi yang sesuai.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if($sales->hasPages()): ?><div class="card-footer bg-transparent d-flex justify-content-between align-items-center flex-wrap gap-2">
        <small class="text-muted">Menampilkan <?php echo e($sales->firstItem()); ?>-<?php echo e($sales->lastItem()); ?> dari <?php echo e($sales->total()); ?></small><?php echo e($sales->links()); ?></div><?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel12-app\anteiku\anteiku\resources\views/sales/index.blade.php ENDPATH**/ ?>