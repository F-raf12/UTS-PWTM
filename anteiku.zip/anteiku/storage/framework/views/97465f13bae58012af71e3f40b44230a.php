<?php $__env->startSection('title', 'Laporan Penjualan'); ?>
<?php $__env->startSection('heading', 'Laporan Penjualan'); ?>
<?php $__env->startSection('content'); ?>
<div class="card mb-3"><div class="card-body">
    <form class="row g-2 align-items-end" method="GET">
        <div class="col-lg-2 col-6"><label class="form-label">Dari tanggal</label>
            <input type="date" name="from" value="<?php echo e($from->toDateString()); ?>" class="form-control <?php $__errorArgs = ['from'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required></div>
        <div class="col-lg-2 col-6"><label class="form-label">Sampai tanggal</label>
            <input type="date" name="to" value="<?php echo e($to->toDateString()); ?>" class="form-control <?php $__errorArgs = ['to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
            <?php $__errorArgs = ['to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
        <div class="col-lg-2 col-6"><label class="form-label">Kasir</label>
            <select name="cashier" class="form-select"><option value="">Semua</option>
            <?php $__currentLoopData = $cashiers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($c->id); ?>" <?php if(request('cashier') == $c->id): echo 'selected'; endif; ?>><?php echo e($c->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
        <div class="col-lg-2 col-6"><label class="form-label">Pembayaran</label>
            <select name="payment" class="form-select"><option value="">Semua</option>
            <?php $__currentLoopData = \App\Models\Sale::METHODS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($k); ?>" <?php if(request('payment') == $k): echo 'selected'; endif; ?>><?php echo e($v); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
        <div class="col-lg-4 d-flex gap-2 flex-wrap">
            <button class="btn btn-primary"><i class="bi bi-funnel"></i> Tampilkan</button>
            <a href="<?php echo e(route('reports.index')); ?>" class="btn btn-soft">Bulan ini</a>
            <a href="<?php echo e(route('reports.pdf', request()->query())); ?>" class="btn btn-accent"><i class="bi bi-file-earmark-pdf"></i> Unduh PDF</a>
        </div>
    </form>
</div></div>

<div class="row g-3 mb-3">
    <div class="col-sm-6 col-xl-3"><div class="card stat"><div class="stat-icon c1"><i class="bi bi-cash-stack"></i></div>
        <div><div class="label">Total Pendapatan</div><div class="value"><?php echo 'Rp ' . number_format((int) ($summary['revenue']), 0, ',', '.'); ?></div></div></div></div>
    <div class="col-sm-6 col-xl-3"><div class="card stat"><div class="stat-icon c2"><i class="bi bi-receipt"></i></div>
        <div><div class="label">Jumlah Transaksi</div><div class="value"><?php echo e($summary['count']); ?></div></div></div></div>
    <div class="col-sm-6 col-xl-3"><div class="card stat"><div class="stat-icon c3"><i class="bi bi-cup-hot"></i></div>
        <div><div class="label">Item Terjual</div><div class="value"><?php echo e($summary['items']); ?></div></div></div></div>
    <div class="col-sm-6 col-xl-3"><div class="card stat"><div class="stat-icon c4"><i class="bi bi-graph-up"></i></div>
        <div><div class="label">Rata-rata / Transaksi</div><div class="value"><?php echo 'Rp ' . number_format((int) ($summary['average']), 0, ',', '.'); ?></div></div></div></div>
</div>

<div class="row g-3 mb-3">
    <div class="col-lg-7"><div class="card h-100">
        <div class="card-header">Penjualan per Hari</div>
        <div class="table-responsive" style="max-height:340px">
            <table class="table"><thead><tr><th>Tanggal</th><th>Transaksi</th><th class="text-end">Pendapatan</th><th style="width:30%"></th></tr></thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $daily; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr><td><?php echo e(\Carbon\Carbon::parse($date)->translatedFormat('D, d M Y')); ?></td><td><?php echo e($row['count']); ?></td><td class="text-end fw-medium"><?php echo 'Rp ' . number_format((int) ($row['total']), 0, ',', '.'); ?></td>
                    <td><div class="progress" style="height:8px"><div class="progress-bar" style="width:<?php echo e(round($row['total'] / $dailyMax * 100)); ?>%;background:var(--caramel)"></div></div></td></tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="4" class="empty">Tidak ada penjualan pada periode ini.</td></tr>
            <?php endif; ?>
            </tbody></table>
        </div>
    </div></div>
    <div class="col-lg-5"><div class="card h-100">
        <div class="card-header">Produk Terlaris</div>
        <div class="table-responsive"><table class="table"><thead><tr><th>Produk</th><th>Qty</th><th class="text-end">Pendapatan</th></tr></thead><tbody>
            <?php $__empty_1 = true; $__currentLoopData = $topProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><tr><td><?php echo e($t->product_name); ?></td><td><?php echo e($t->qty); ?></td><td class="text-end"><?php echo 'Rp ' . number_format((int) ($t->revenue), 0, ',', '.'); ?></td></tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="3" class="empty">Tidak ada data.</td></tr><?php endif; ?>
        </tbody></table></div>
    </div></div>
</div>

<div class="card">
    <div class="card-header">Daftar Transaksi (<?php echo e($from->translatedFormat('d M Y')); ?> - <?php echo e($to->translatedFormat('d M Y')); ?>)</div>
    <div class="table-responsive"><table class="table">
        <thead><tr><th>Invoice</th><th>Waktu</th><th>Pelanggan</th><th>Kasir</th><th>Pembayaran</th><th class="text-end">Total</th></tr></thead>
        <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr><td><a href="<?php echo e(route('sales.show', $s)); ?>" class="fw-medium"><?php echo e($s->invoice_no); ?></a></td><td class="text-muted"><?php echo e($s->sold_at->translatedFormat('d M Y, H:i')); ?></td>
                <td><?php echo e($s->customer->name ?? 'Umum'); ?></td><td><?php echo e($s->user->name); ?></td><td><?php echo e($s->method_label); ?></td><td class="text-end fw-medium"><?php echo 'Rp ' . number_format((int) ($s->total), 0, ',', '.'); ?></td></tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="6" class="empty">Tidak ada transaksi.</td></tr><?php endif; ?>
        </tbody>
    </table></div>
    <?php if($sales->hasPages()): ?><div class="card-footer bg-transparent d-flex justify-content-between align-items-center flex-wrap gap-2">
        <small class="text-muted">Menampilkan <?php echo e($sales->firstItem()); ?>-<?php echo e($sales->lastItem()); ?> dari <?php echo e($sales->total()); ?></small><?php echo e($sales->links()); ?></div><?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel12-app\anteiku\anteiku\resources\views/reports/index.blade.php ENDPATH**/ ?>