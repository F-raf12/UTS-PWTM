<?php $__env->startSection('title', 'Pelanggan'); ?>
<?php $__env->startSection('heading', 'Pelanggan'); ?>
<?php $__env->startSection('content'); ?>
<?php ($admin = auth()->user()->isAdmin()); ?>
<div class="card">
    <div class="filter-bar">
        <form class="row g-2 align-items-center auto-submit" method="GET">
            <div class="col-lg-4 col-md-6"><div class="input-group"><span class="input-group-text"><i class="bi bi-search"></i></span>
                <input type="search" name="q" value="<?php echo e(request('q')); ?>" class="form-control" placeholder="Cari nama, telepon, email..."></div></div>
            <div class="col-lg-2 col-6"><select name="filter" class="form-select">
                <option value="">Semua pelanggan</option>
                <option value="buyer" <?php if(request('filter') == 'buyer'): echo 'selected'; endif; ?>>Pernah membeli</option>
                <option value="new" <?php if(request('filter') == 'new'): echo 'selected'; endif; ?>>Belum pernah membeli</option>
            </select></div>
            <div class="col-auto"><button class="btn btn-soft">Cari</button>
                <?php if(request()->hasAny(['q','filter','sort'])): ?><a href="<?php echo e(route('customers.index')); ?>" class="btn btn-link">Reset</a><?php endif; ?></div>
            <div class="col text-lg-end"><a href="<?php echo e(route('customers.create')); ?>" class="btn btn-primary"><i class="bi bi-plus-lg"></i> Tambah Pelanggan</a></div>
        </form>
    </div>
    <div class="table-responsive">
        <table class="table">
            <thead><tr>
                <th>#</th>
                <th><?php if (isset($component)) { $__componentOriginal6a44cb87e86b7d587c0ef29d28e1a20e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6a44cb87e86b7d587c0ef29d28e1a20e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sort','data' => ['col' => 'name','sort' => $sort,'dir' => $dir]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sort'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['col' => 'name','sort' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sort),'dir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($dir)]); ?>Nama <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6a44cb87e86b7d587c0ef29d28e1a20e)): ?>
<?php $attributes = $__attributesOriginal6a44cb87e86b7d587c0ef29d28e1a20e; ?>
<?php unset($__attributesOriginal6a44cb87e86b7d587c0ef29d28e1a20e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6a44cb87e86b7d587c0ef29d28e1a20e)): ?>
<?php $component = $__componentOriginal6a44cb87e86b7d587c0ef29d28e1a20e; ?>
<?php unset($__componentOriginal6a44cb87e86b7d587c0ef29d28e1a20e); ?>
<?php endif; ?></th>
                <th><?php if (isset($component)) { $__componentOriginal6a44cb87e86b7d587c0ef29d28e1a20e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6a44cb87e86b7d587c0ef29d28e1a20e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sort','data' => ['col' => 'phone','sort' => $sort,'dir' => $dir]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sort'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['col' => 'phone','sort' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sort),'dir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($dir)]); ?>Telepon <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6a44cb87e86b7d587c0ef29d28e1a20e)): ?>
<?php $attributes = $__attributesOriginal6a44cb87e86b7d587c0ef29d28e1a20e; ?>
<?php unset($__attributesOriginal6a44cb87e86b7d587c0ef29d28e1a20e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6a44cb87e86b7d587c0ef29d28e1a20e)): ?>
<?php $component = $__componentOriginal6a44cb87e86b7d587c0ef29d28e1a20e; ?>
<?php unset($__componentOriginal6a44cb87e86b7d587c0ef29d28e1a20e); ?>
<?php endif; ?></th>
                <th>Email</th><th>Alamat</th>
                <th><?php if (isset($component)) { $__componentOriginal6a44cb87e86b7d587c0ef29d28e1a20e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6a44cb87e86b7d587c0ef29d28e1a20e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sort','data' => ['col' => 'sales_count','sort' => $sort,'dir' => $dir]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sort'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['col' => 'sales_count','sort' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sort),'dir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($dir)]); ?>Transaksi <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6a44cb87e86b7d587c0ef29d28e1a20e)): ?>
<?php $attributes = $__attributesOriginal6a44cb87e86b7d587c0ef29d28e1a20e; ?>
<?php unset($__attributesOriginal6a44cb87e86b7d587c0ef29d28e1a20e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6a44cb87e86b7d587c0ef29d28e1a20e)): ?>
<?php $component = $__componentOriginal6a44cb87e86b7d587c0ef29d28e1a20e; ?>
<?php unset($__componentOriginal6a44cb87e86b7d587c0ef29d28e1a20e); ?>
<?php endif; ?></th>
                <th class="text-end">Aksi</th>
            </tr></thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($customers->firstItem() + $loop->index); ?></td>
                    <td class="fw-medium"><?php echo e($c->name); ?></td>
                    <td><?php echo e($c->phone ?: '-'); ?></td>
                    <td><?php echo e($c->email ?: '-'); ?></td>
                    <td class="text-muted"><?php echo e(\Illuminate\Support\Str::limit($c->address, 30) ?: '-'); ?></td>
                    <td><span class="badge-soft badge-brown"><?php echo e($c->sales_count); ?>x</span></td>
                    <td class="text-end text-nowrap">
                        <a href="<?php echo e(route('customers.edit', $c)); ?>" class="btn btn-sm btn-soft" title="Ubah"><i class="bi bi-pencil"></i></a>
                        <?php if($admin): ?><?php if (isset($component)) { $__componentOriginal31d8dad53715b0a3883f430a1e78226c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal31d8dad53715b0a3883f430a1e78226c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.confirm-delete','data' => ['action' => route('customers.destroy', $c),'message' => 'Hapus pelanggan '.e($c->name).'?']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('confirm-delete'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['action' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('customers.destroy', $c)),'message' => 'Hapus pelanggan '.e($c->name).'?']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal31d8dad53715b0a3883f430a1e78226c)): ?>
<?php $attributes = $__attributesOriginal31d8dad53715b0a3883f430a1e78226c; ?>
<?php unset($__attributesOriginal31d8dad53715b0a3883f430a1e78226c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal31d8dad53715b0a3883f430a1e78226c)): ?>
<?php $component = $__componentOriginal31d8dad53715b0a3883f430a1e78226c; ?>
<?php unset($__componentOriginal31d8dad53715b0a3883f430a1e78226c); ?>
<?php endif; ?><?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="7" class="empty"><i class="bi bi-people"></i>Pelanggan tidak ditemukan.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if($customers->hasPages()): ?><div class="card-footer bg-transparent d-flex justify-content-between align-items-center flex-wrap gap-2">
        <small class="text-muted">Menampilkan <?php echo e($customers->firstItem()); ?>-<?php echo e($customers->lastItem()); ?> dari <?php echo e($customers->total()); ?></small><?php echo e($customers->links()); ?></div><?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel12-app\anteiku\anteiku\resources\views/customers/index.blade.php ENDPATH**/ ?>