<!DOCTYPE html>
<html lang="id"><head><meta charset="utf-8"><title>Laporan Penjualan Anteiku</title>
<style>
body{font-family:DejaVu Sans,sans-serif;font-size:10.5px;color:#2b211b}
h1{font-size:20px;margin:0;color:#2a1b14} h2{font-size:13px;margin:18px 0 6px;color:#6f4a33}
.sub{color:#8b7b6e;margin-bottom:12px}
table{width:100%;border-collapse:collapse}th,td{border:1px solid #e3d6c6;padding:5px 7px;text-align:left}
th{background:#ecdcc8;color:#2a1b14}.r{text-align:right}.sum td{border:0;padding:2px 0}
.head{border-bottom:3px solid #c08552;padding-bottom:8px;margin-bottom:10px}
</style></head><body>
<div class="head"><h1>Anteiku Coffee &amp; Dessert</h1><div>Laporan Penjualan</div></div>
<div class="sub">Periode: <?php echo e($from->translatedFormat('d F Y')); ?> - <?php echo e($to->translatedFormat('d F Y')); ?> &middot; Dicetak: <?php echo e(now()->translatedFormat('d F Y H:i')); ?></div>

<h2>Ringkasan</h2>
<table class="sum">
<tr><td>Total pendapatan</td><td class="r"><b><?php echo 'Rp ' . number_format((int) ($summary['revenue']), 0, ',', '.'); ?></b></td></tr>
<tr><td>Jumlah transaksi</td><td class="r"><?php echo e($summary['count']); ?></td></tr>
<tr><td>Item terjual</td><td class="r"><?php echo e($summary['items']); ?></td></tr>
<tr><td>Rata-rata per transaksi</td><td class="r"><?php echo 'Rp ' . number_format((int) ($summary['average']), 0, ',', '.'); ?></td></tr>
</table>

<h2>Penjualan per Hari</h2>
<table><tr><th>Tanggal</th><th class="r">Transaksi</th><th class="r">Pendapatan</th></tr>
<?php $__empty_1 = true; $__currentLoopData = $daily; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<tr><td><?php echo e(\Carbon\Carbon::parse($date)->format('d/m/Y')); ?></td><td class="r"><?php echo e($row['count']); ?></td><td class="r"><?php echo 'Rp ' . number_format((int) ($row['total']), 0, ',', '.'); ?></td></tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="3">Tidak ada transaksi.</td></tr><?php endif; ?>
</table>

<h2>Produk Terlaris</h2>
<table><tr><th>Produk</th><th class="r">Qty</th><th class="r">Pendapatan</th></tr>
<?php $__empty_1 = true; $__currentLoopData = $topProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><tr><td><?php echo e($t->product_name); ?></td><td class="r"><?php echo e($t->qty); ?></td><td class="r"><?php echo 'Rp ' . number_format((int) ($t->revenue), 0, ',', '.'); ?></td></tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="3">Tidak ada data.</td></tr><?php endif; ?>
</table>

<h2>Daftar Transaksi</h2>
<table><tr><th>Invoice</th><th>Waktu</th><th>Pelanggan</th><th>Kasir</th><th>Bayar</th><th class="r">Total</th></tr>
<?php $__empty_1 = true; $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<tr><td><?php echo e($s->invoice_no); ?></td><td><?php echo e($s->sold_at->format('d/m/Y H:i')); ?></td><td><?php echo e($s->customer->name ?? 'Umum'); ?></td><td><?php echo e($s->user->name); ?></td><td><?php echo e($s->method_label); ?></td><td class="r"><?php echo 'Rp ' . number_format((int) ($s->total), 0, ',', '.'); ?></td></tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="6">Tidak ada transaksi.</td></tr><?php endif; ?>
</table>
</body></html>
<?php /**PATH C:\xampp\htdocs\laravel12-app\anteiku\anteiku\resources\views/reports/pdf.blade.php ENDPATH**/ ?>