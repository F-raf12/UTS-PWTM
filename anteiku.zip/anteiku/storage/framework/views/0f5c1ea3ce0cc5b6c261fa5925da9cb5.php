<?php if(session('status')): ?>
    <div class="alert alert-success border-0 shadow-sm alert-dismissible fade show" role="alert" style="background:#e1f0e6;color:#2f6e46">
        <i class="bi bi-check-circle-fill me-1"></i> <?php echo e(session('status')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>
<?php if(session('error')): ?>
    <div class="alert alert-danger border-0 shadow-sm alert-dismissible fade show" role="alert" style="background:#f8e1de;color:#9b3328">
        <i class="bi bi-exclamation-triangle-fill me-1"></i> <?php echo e(session('error')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\laravel12-app\anteiku\anteiku\resources\views/partials/flash.blade.php ENDPATH**/ ?>