<?php $__env->startSection('title', 'Akses Ditolak'); ?>
<?php $__env->startSection('heading', 'Akses Ditolak'); ?>
<?php $__env->startSection('content'); ?>
<div class="card"><div class="empty">
    <i class="bi bi-shield-lock"></i>
    <h3 class="serif mt-2">403</h3>
    <p><?php echo e($exception->getMessage() ?: 'Anda tidak memiliki hak akses untuk halaman ini.'); ?></p>
    <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-primary">Kembali ke Dashboard</a>
</div></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make(auth()->check() ? 'layouts.app' : 'layouts.plain', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel12-app\anteiku\anteiku\resources\views/errors/403.blade.php ENDPATH**/ ?>