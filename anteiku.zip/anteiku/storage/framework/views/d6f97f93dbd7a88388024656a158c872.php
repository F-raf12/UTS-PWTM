<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('heading', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="hero mb-4">
    <h2>Halo, <?php echo e(auth()->user()->name); ?> ☕</h2>
    <p>
        <?php if(auth()->user()->isAdmin()): ?> Ringkasan seluruh penjualan Anteiku hari ini.
        <?php else: ?> Ringkasan transaksi yang Anda layani. Semangat melayani!<?php endif; ?>
    </p>
</div>

<div class="row g-3 mb-4">
    <div class="col-sm-6 col-xl-3"><div class="card stat">
        <div class="stat-icon c1"><i class="bi bi-cash-coin"></i></div>
        <div><div class="label">Total Penjualan</div><div class="value"><?php echo 'Rp ' . number_format((int) ($totalSales), 0, ',', '.'); ?></div><small class="text-muted">Bulan ini <?php echo 'Rp ' . number_format((int) ($monthSales), 0, ',', '.'); ?></small></div>
    </div></div>
    <div class="col-sm-6 col-xl-3"><div class="card stat">
        <div class="stat-icon c2"><i class="bi bi-receipt-cutoff"></i></div>
        <div><div class="label">Jumlah Transaksi</div><div class="value"><?php echo e(number_format($saleCount, 0, ',', '.')); ?></div><small class="text-muted">Hari ini <?php echo e($todayCount); ?> transaksi</small></div>
    </div></div>
    <div class="col-sm-6 col-xl-3"><div class="card stat">
        <div class="stat-icon c3"><i class="bi bi-cup-hot"></i></div>
        <div><div class="label">Jumlah Produk</div><div class="value"><?php echo e($productCount); ?></div><small class="text-muted"><?php echo e($lowStock->count()); ?> stok menipis</small></div>
    </div></div>
    <div class="col-sm-6 col-xl-3"><div class="card stat">
        <div class="stat-icon c4"><i class="bi bi-people"></i></div>
        <div><div class="label">Pelanggan</div><div class="value"><?php echo e($customerCount); ?></div><small class="text-muted">Hari ini <?php echo 'Rp ' . number_format((int) ($todaySales), 0, ',', '.'); ?></small></div>
    </div></div>
</div>

<div class="row g-3 mb-3">
    <div class="col-lg-8">
        <div class="card h-100">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span>Penjualan 7 Hari Terakhir</span>
                <a href="<?php echo e(route('sales.create')); ?>" class="btn btn-sm btn-primary"><i class="bi bi-plus-lg"></i> Transaksi Baru</a>
            </div>
            <div class="card-body">
                <div class="bars">
                    <?php $__currentLoopData = $chart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="bar-col" title="<?php echo e($c['date']); ?>: Rp <?php echo e(number_format($c['total'], 0, ',', '.')); ?>">
                            <div class="bar-val"><?php echo e($c['total'] ? number_format($c['total'] / 1000, 0, ',', '.') . 'k' : '0'); ?></div>
                            <div class="bar" style="height:<?php echo e(max(2, round($c['total'] / $chartMax * 100))); ?>%"></div>
                            <div class="bar-lbl"><?php echo e($c['label']); ?></div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="card h-100">
            <div class="card-header"><i class="bi bi-fire text-danger"></i> Produk Terlaris</div>
            <ul class="list-group list-group-flush">
                <?php $__empty_1 = true; $__currentLoopData = $bestSellers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <li class="list-group-item d-flex align-items-center gap-3 py-3">
                        <span class="badge-soft badge-brown"><?php echo e($i + 1); ?></span>
                        <div class="flex-grow-1"><div class="fw-medium"><?php echo e($b->product_name); ?></div><small class="text-muted"><?php echo 'Rp ' . number_format((int) ($b->revenue), 0, ',', '.'); ?></small></div>
                        <strong><?php echo e($b->qty); ?>x</strong>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <li class="list-group-item empty border-0">Belum ada penjualan.</li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</div>

<div class="row g-3">
    <div class="col-lg-8">
        <div class="card">
            <div class="card-header d-flex justify-content-between"><span>Transaksi Terbaru</span><a href="<?php echo e(route('sales.index')); ?>" class="small">Lihat semua</a></div>
            <div class="table-responsive">
                <table class="table">
                    <thead><tr><th>Invoice</th><th>Pelanggan</th><th>Waktu</th><th class="text-end">Total</th></tr></thead>
                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $recent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><a href="<?php echo e(route('sales.show', $s)); ?>" class="fw-medium"><?php echo e($s->invoice_no); ?></a>
                                <?php if($s->status === 'cancelled'): ?><span class="badge-soft badge-bad ms-1">Batal</span><?php endif; ?></td>
                            <td><?php echo e($s->customer->name ?? 'Umum'); ?></td>
                            <td class="text-muted"><?php echo e($s->sold_at->translatedFormat('d M, H:i')); ?></td>
                            <td class="text-end fw-medium"><?php echo 'Rp ' . number_format((int) ($s->total), 0, ',', '.'); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="4" class="empty">Belum ada transaksi.</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="card">
            <div class="card-header"><i class="bi bi-exclamation-triangle text-warning"></i> Stok Menipis</div>
            <ul class="list-group list-group-flush">
                <?php $__empty_1 = true; $__currentLoopData = $lowStock; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <li class="list-group-item d-flex justify-content-between align-items-center py-3">
                        <span><?php echo e($p->name); ?></span>
                        <span class="badge-soft <?php echo e($p->stock == 0 ? 'badge-bad' : 'badge-warn'); ?>"><?php echo e($p->stock == 0 ? 'Habis' : 'Sisa ' . $p->stock); ?></span>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <li class="list-group-item empty border-0">Semua stok aman 👍</li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel12-app\anteiku\anteiku\resources\views/dashboard/index.blade.php ENDPATH**/ ?>