<script src="<?php echo e(asset('vendor/bootstrap/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<?php /**PATH C:\xampp\htdocs\laravel12-app\anteiku\anteiku\resources\views/partials/scripts.blade.php ENDPATH**/ ?>