<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'Dashboard'); ?> - Anteiku</title>
    <?php echo $__env->make('partials.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</head>
<body>
<?php ($u = auth()->user()); ?>
<aside class="sidebar" id="sidebar">
    <a href="<?php echo e(route('dashboard')); ?>" class="brand">
        <span class="brand-icon"><i class="bi bi-cup-hot-fill"></i></span>
        <span><span class="brand-name">Anteiku</span><small>Coffee &amp; Dessert</small></span>
    </a>

    <nav>
        <a href="<?php echo e(route('dashboard')); ?>" class="side-link <?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>"><i class="bi bi-grid-1x2-fill"></i> Dashboard</a>

        <div class="nav-label">Penjualan</div>
        <a href="<?php echo e(route('sales.create')); ?>" class="side-link <?php echo e(request()->routeIs('sales.create') ? 'active' : ''); ?>"><i class="bi bi-bag-plus-fill"></i> Transaksi Baru</a>
        <a href="<?php echo e(route('sales.index')); ?>" class="side-link <?php echo e(request()->routeIs('sales.index', 'sales.show') ? 'active' : ''); ?>"><i class="bi bi-receipt"></i> Riwayat Transaksi</a>

        <div class="nav-label">Data Master</div>
        <a href="<?php echo e(route('products.index')); ?>" class="side-link <?php echo e(request()->routeIs('products.*') ? 'active' : ''); ?>"><i class="bi bi-cup-straw"></i> Produk</a>
        <?php if($u->isAdmin()): ?>
            <a href="<?php echo e(route('categories.index')); ?>" class="side-link <?php echo e(request()->routeIs('categories.*') ? 'active' : ''); ?>"><i class="bi bi-tags-fill"></i> Kategori</a>
        <?php endif; ?>
        <a href="<?php echo e(route('customers.index')); ?>" class="side-link <?php echo e(request()->routeIs('customers.*') ? 'active' : ''); ?>"><i class="bi bi-people-fill"></i> Pelanggan</a>

        <?php if($u->isAdmin()): ?>
            <div class="nav-label">Administrasi</div>
            <a href="<?php echo e(route('reports.index')); ?>" class="side-link <?php echo e(request()->routeIs('reports.*') ? 'active' : ''); ?>"><i class="bi bi-bar-chart-line-fill"></i> Laporan Penjualan</a>
            <a href="<?php echo e(route('users.index')); ?>" class="side-link <?php echo e(request()->routeIs('users.*') ? 'active' : ''); ?>"><i class="bi bi-person-gear"></i> Manajemen User</a>
        <?php endif; ?>
    </nav>

    <div class="side-user mt-4">
        <div class="avatar"><?php echo e($u->initials); ?></div>
        <div class="flex-grow-1 overflow-hidden">
            <div class="text-white fw-medium text-truncate"><?php echo e($u->name); ?></div>
            <small style="color:#bda58c"><?php echo e($u->role_label); ?></small>
        </div>
        <form method="POST" action="<?php echo e(route('logout')); ?>"><?php echo csrf_field(); ?>
            <button class="btn btn-sm text-white-50 p-1" title="Keluar" type="submit"><i class="bi bi-box-arrow-right fs-5"></i></button>
        </form>
    </div>
</aside>

<div class="main">
    <header class="topbar">
        <button class="btn btn-soft d-lg-none" id="sidebarToggle" type="button" aria-label="Menu"><i class="bi bi-list fs-5"></i></button>
        <h1 class="flex-grow-1"><?php echo $__env->yieldContent('heading', 'Dashboard'); ?></h1>
        <span class="text-muted d-none d-md-inline"><i class="bi bi-calendar3"></i> <?php echo e(now()->translatedFormat('l, d F Y')); ?></span>
    </header>

    <main class="content">
        <?php echo $__env->make('partials.flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>
    </main>
</div>

<?php echo $__env->make('partials.scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel12-app\anteiku\anteiku\resources\views/layouts/app.blade.php ENDPATH**/ ?>