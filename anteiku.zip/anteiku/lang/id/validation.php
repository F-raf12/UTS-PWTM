<?php

return [
    'accepted'  => ':attribute harus diterima.',
    'after_or_equal' => ':attribute harus berupa tanggal setelah atau sama dengan :date.',
    'array'     => ':attribute harus berupa array.',
    'confirmed' => 'Konfirmasi :attribute tidak cocok.',
    'date'      => ':attribute bukan tanggal yang valid.',
    'distinct'  => ':attribute memiliki nilai duplikat.',
    'email'     => ':attribute harus berupa alamat email yang valid.',
    'exists'    => ':attribute yang dipilih tidak valid.',
    'image'     => ':attribute harus berupa gambar.',
    'in'        => ':attribute yang dipilih tidak valid.',
    'integer'   => ':attribute harus berupa bilangan bulat.',
    'max' => [
        'numeric' => ':attribute tidak boleh lebih dari :max.',
        'file'    => 'Ukuran :attribute tidak boleh lebih dari :max kilobyte.',
        'string'  => ':attribute tidak boleh lebih dari :max karakter.',
        'array'   => ':attribute tidak boleh lebih dari :max item.',
    ],
    'mimes'     => ':attribute harus berupa file bertipe: :values.',
    'min' => [
        'numeric' => ':attribute minimal :min.',
        'file'    => 'Ukuran :attribute minimal :min kilobyte.',
        'string'  => ':attribute minimal :min karakter.',
        'array'   => ':attribute minimal memiliki :min item.',
    ],
    'regex'     => 'Format :attribute tidak valid.',
    'required'  => ':attribute wajib diisi.',
    'string'    => ':attribute harus berupa teks.',
    'unique'    => ':attribute sudah digunakan.',
    'uploaded'  => ':attribute gagal diunggah.',

    'attributes' => [
        'name' => 'Nama', 'email' => 'Email', 'password' => 'Password', 'role' => 'Role',
        'description' => 'Deskripsi', 'category_id' => 'Kategori', 'price' => 'Harga', 'stock' => 'Stok',
        'image' => 'Gambar', 'phone' => 'Nomor telepon', 'address' => 'Alamat', 'paid' => 'Uang diterima',
        'payment_method' => 'Metode pembayaran', 'customer_id' => 'Pelanggan', 'items' => 'Keranjang',
        'from' => 'Tanggal awal', 'to' => 'Tanggal akhir', 'notes' => 'Catatan',
    ],
];
